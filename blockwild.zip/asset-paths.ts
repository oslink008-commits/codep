type EmbeddedGameAssets = { mossWarden?: string; favicon?: string }
const embedded = (globalThis as typeof globalThis & { __BLOCKWILD_EMBEDDED_ASSETS__?: EmbeddedGameAssets }).__BLOCKWILD_EMBEDDED_ASSETS__

// A standalone file can inject data URLs; normal Vite/dev and production paths remain unchanged.
const mossWarden = embedded?.mossWarden ?? (import.meta.env.DEV
  ? '/assets/models/moss-warden.glb'
  : '/manus-storage/game/sha256/ff8b6820cab998fa1c944cd384d78e3322b5ab28600d6a7c64b7ac17046fc2a4.glb')

export const GAME_ASSETS = {
  mossWarden,
  favicon: embedded?.favicon ?? './favicon.svg',
} as const
