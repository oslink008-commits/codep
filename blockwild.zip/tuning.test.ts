import { afterEach, describe, expect, it } from 'vitest'
import { CONFIG, DEFAULT_CONFIG } from '../src/game/config'
import { tuning } from '../src/game/tuning'

const defaults = Object.fromEntries(tuning.controls.map(control => [control.id, control.default]))
const reset = (): void => {
  tuning.apply(defaults)
  tuning.activate('jump')
  tuning.activate('run')
}
afterEach(reset)

describe('Three.js survival tuning', () => {
  it('validates a complete patch before committing and preserves source defaults', () => {
    const before = tuning.read()
    for (const patch of [
      { 'player.walkSpeed': 15, 'camera.fov': 999 },
      { 'player.walkSpeed': 12 },
      { 'player.walkSpeed': 7.1 },
      { 'player.walkSpeed': '8' },
      { 'camera.fov': Infinity },
      { unknown: 4 },
    ]) {
      expect(() => tuning.apply(patch)).toThrow()
      expect(tuning.read()).toEqual(before)
    }
    tuning.apply({ 'player.walkSpeed': 9, 'player.sprintSpeed': 13 })
    expect(CONFIG.player.walkSpeed).toBe(9)
    expect(CONFIG.player.sprintSpeed).toBe(13)
    expect(DEFAULT_CONFIG.player.walkSpeed).toBe(7)
  })

  it('keeps next-jump values pending and applies survival rates live', () => {
    tuning.apply({ 'player.jumpSpeed': 14, 'survival.thirstRate': 0.28 })
    expect(CONFIG.player.jumpSpeed).toBe(DEFAULT_CONFIG.player.jumpSpeed)
    expect(CONFIG.survival.thirstRate).toBe(0.28)
    tuning.activate('jump')
    expect(CONFIG.player.jumpSpeed).toBe(14)
    tuning.apply({ 'player.jumpSpeed': 16 })
    expect(CONFIG.player.jumpSpeed).toBe(14)
    tuning.activate('jump')
    expect(CONFIG.player.jumpSpeed).toBe(16)
  })

  it('registers only tuning controls that have gameplay consumers', () => {
    const ids = new Set(tuning.controls.map(control => control.id))
    for (const id of ['player.walkSpeed', 'player.sprintSpeed', 'player.acceleration', 'player.jumpSpeed', 'camera.fov', 'survival.hungerRate', 'survival.thirstRate']) {
      expect(ids.has(id)).toBe(true)
    }
    for (const id of ['player.dashSpeed', 'player.airControl', 'camera.distance', 'run.lives']) expect(ids.has(id)).toBe(false)
  })

  it('preserves the unranked latch for gameplay tuning until a fresh run', () => {
    tuning.activate('run')
    tuning.apply({ 'camera.fov': 90 })
    expect(tuning.unranked).toBe(false)
    tuning.apply({ 'survival.thirstRate': 0.2 })
    expect(tuning.unranked).toBe(true)
    tuning.apply(defaults)
    expect(tuning.unranked).toBe(true)
    tuning.activate('run')
    expect(tuning.unranked).toBe(false)
  })
})
