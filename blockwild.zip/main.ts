import './styles/main.css'
import './styles/survival.css'
import { Audio } from './engine/audio'
import { Assets } from './engine/assets'
import { Input } from './engine/input'
import { GameLoop } from './engine/loop'
import { SAVE_KEY, SaveStore, type SaveData } from './engine/save'
import type { SurvivalGame } from './game/survival-game'
import type { SurvivalAction, SurvivalUI } from './ui/survival-ui'
import { TouchControls } from './ui/touch'
import { GAME_ASSETS } from './game/asset-paths'

async function boot(): Promise<void> {
  document.documentElement.lang = 'vi-VN'
  document.title = 'Blockwild: Voxel Survival'
  const canvas = document.querySelector<HTMLCanvasElement>('#game')!
  const root = document.getElementById('ui')!
  const firstRun = safeGet(SAVE_KEY) === null
  const save = new SaveStore()
  const input = new Input(canvas)
  const audio = new Audio()
  let game: SurvivalGame | undefined
  let loop: GameLoop | undefined
  let ui!: SurvivalUI
  let retryRequiredAsset: () => void = () => {}
  let intentionalPointerUnlockUntil = 0
  let lockLostAt = 0
  let hudTimer = 0

  const [{ SurvivalUI }] = await Promise.all([
    import('./ui/survival-ui'),
    document.fonts.ready,
  ])

  const applySettings = (data: SaveData): void => {
    input.sensitivity = data.sensitivity
    input.invertY = data.invertY
    audio.setVolumes(data.musicVolume, data.sfxVolume, data.muted)
    if (game) game.reducedMotion = data.reducedMotion
  }
  const startRun = (): void => {
    if (!game) return
    audio.unlock()
    game.start()
    ui.setScreen('playing')
    loop?.resetAccumulator()
    if (!matchMedia('(pointer: coarse)').matches) input.lockPointer()
  }
  const pause = (): void => {
    if (game?.mode !== 'playing') return
    game.pause()
    ui.setScreen('paused')
    input.unlockPointer()
  }
  const resume = (): void => {
    if (game?.mode !== 'paused') return
    game.resume()
    ui.setScreen('playing')
    loop?.resetAccumulator()
    if (!matchMedia('(pointer: coarse)').matches) input.lockPointer()
  }

  ui = new SurvivalUI(root, {
    start: startRun,
    pause,
    resume,
    retry: () => retryRequiredAsset(),
    home: () => {
      game?.toTitle()
      ui.setScreen('title')
      input.unlockPointer()
    },
    openCraft: () => {
      intentionalPointerUnlockUntil = performance.now() + 350
      input.unlockPointer()
      ui.openCraft()
    },
    closeCraft: () => {
      ui.closeCraft()
      if (game?.mode === 'playing' && !matchMedia('(pointer: coarse)').matches) input.lockPointer()
    },
    craft: recipe => game?.craft(recipe),
    select: slot => game?.selectSlot(slot),
    touch: (action: SurvivalAction, down: boolean) => input.setTouchButton(action, down),
  })
  const bootIcon = root.querySelector<HTMLImageElement>('.survival-boot-icon')
  if (bootIcon) bootIcon.src = GAME_ASSETS.favicon
  ui.setScreen('boot')
  ui.setBootProgress(14)
  applySettings(save.data)

  const [{ SurvivalGame }, rendererModule] = await Promise.all([
    import('./game/survival-game'),
    import('./engine/renderer'),
  ])
  if (firstRun) save.update({ quality: rendererModule.suggestQuality() })
  ui.setBootProgress(70)
  const renderer = new rendererModule.Renderer(canvas, save.data.quality)
  let enemyAsset: Awaited<ReturnType<Assets['gltf']>> | undefined
  while (!enemyAsset) {
    ui.setBootError('')
    const assets = new Assets()
    const stopProgress = assets.onProgress(progress => ui.setBootProgress(72 + progress * 26))
    try {
      enemyAsset = await assets.gltf(GAME_ASSETS.mossWarden)
    } catch {
      stopProgress()
      ui.setBootError('Không tải được sinh vật cần thiết. Hãy kiểm tra mạng rồi thử lại.')
      await new Promise<void>(resolve => { retryRequiredAsset = resolve })
      continue
    }
    stopProgress()
  }
  retryRequiredAsset = () => {}
  game = new SurvivalGame(renderer, input, audio, {
    toast: message => ui.toast(message),
    openCraft: () => {
      intentionalPointerUnlockUntil = performance.now() + 350
      input.unlockPointer()
      ui.openCraft()
    },
  }, enemyAsset)
  game.reducedMotion = save.data.reducedMotion

  if (import.meta.env.DEV) {
    const [{ registerGameTuning }, { tuning }] = await Promise.all([
      import('../scripts/manus-tuning/adapter.js'),
      import('./game/tuning'),
    ])
    await registerGameTuning(tuning)
  }

  ui.setBootProgress(100)
  const activeGame = game
  loop = new GameLoop({
    beforeFrame: frameSeconds => input.update(frameSeconds),
    step: dt => activeGame.step(dt),
    render: (alpha, frameSeconds) => {
      if (input.consume('pause') && performance.now() - lockLostAt > 300) {
        if (activeGame.mode === 'playing') pause()
        else if (activeGame.mode === 'paused') resume()
      }
      loop!.paused = activeGame.mode === 'paused'
      activeGame.render(alpha, frameSeconds)
      if (activeGame.mode === 'playing') {
        hudTimer += frameSeconds
        if (hudTimer >= 0.09) {
          hudTimer = 0
          ui.update(activeGame.snapshot())
        }
      }
    },
  })
  loop.start()

  document.addEventListener('pointerlockchange', () => {
    if (location.protocol !== 'file:' && !document.pointerLockElement && activeGame.mode === 'playing' && input.method === 'keyboard' && !ui.isCraftOpen() && performance.now() > intentionalPointerUnlockUntil) {
      lockLostAt = performance.now()
      pause()
    }
  })
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause() })
  window.addEventListener('game:pause', pause)
  canvas.addEventListener('click', () => {
    if (activeGame.mode === 'playing' && !matchMedia('(pointer: coarse)').matches) input.lockPointer()
  })
  new TouchControls(root, input, () => activeGame.mode === 'playing')
  window.addEventListener('keydown', event => {
    if (activeGame.mode !== 'playing' || event.repeat || !/^Digit[1-9]$/.test(event.code)) return
    activeGame.selectSlot(Number(event.code.slice(-1)) - 1)
  })

  applySettings(save.data)
  window.setTimeout(() => ui.setScreen('title'), 240)
  ;(window as unknown as { __game: unknown }).__game = { game: activeGame, ui, input, save }
}

function safeGet(key: string): string | null {
  try { return localStorage.getItem(key) } catch { return null }
}

boot().catch(error => {
  console.error(error)
  const root = document.getElementById('ui')
  if (root) root.innerHTML = `<div class="fatal">Không thể mở khu rừng: ${String((error as Error)?.message ?? error).replace(/[<>&]/g, '')}</div>`
})
