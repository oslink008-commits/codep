# Blockwild: Voxel Survival

Game sinh tồn voxel 3D đơn người chơi chạy trên trình duyệt, viết bằng TypeScript/JavaScript và Three.js. Khám phá hòn đảo rừng theo ngày/đêm, phá và đặt khối, thu gom gỗ/đá/than, chế tạo vật dụng, giữ sức khỏe–đói–khát và tránh Moss Warden khi trời tối. Tên, thế giới, UI, sinh vật và asset là bản nguyên bản; trò chơi chỉ lấy cảm hứng khái quát từ các game sandbox voxel.

## Chạy bằng một file HTML

Tải `blockwild.html` về và mở bằng Chrome, Edge hoặc Firefox bản mới trên máy tính. File này tự chứa JavaScript đã bundle, CSS, font, favicon và model Warden; không cần cài Node/Vite, giải nén file phụ, mở local server hoặc có Internet. Trình duyệt cần hỗ trợ WebGL và JavaScript module nội tuyến.

Cài đặt được giữ trong bộ nhớ của phiên chơi; nếu chính sách `file://` chặn `localStorage`, game vẫn chơi bình thường nhưng cài đặt có thể không còn sau khi đóng trang. Trên Android, quyền mở HTML cục bộ tùy file manager/trình duyệt; nếu máy không cho mở, dùng bản Preview trên web thay vì đổi nội dung file.

Để tạo lại file từ source (cần Node.js và pnpm):

```bash
pnpm install
pnpm html:single  # tạo/cập nhật blockwild.html
```

## Chạy và kiểm tra bản Web

```bash
pnpm install
pnpm dev         # Vite development server
pnpm typecheck   # TypeScript
pnpm test        # Unit tests
pnpm build       # Web build và sharing metadata trong dist/
pnpm html:single # tạo file HTML tự chứa
pnpm smoke       # desktop/mobile + mở standalone qua file://; cần chạy sau hai lệnh build trên
```

## Điều khiển

Trên máy tính: `WASD` di chuyển, giữ `Shift` chạy, `Space` nhảy, kéo chuột để xoay góc nhìn, `F` hoặc chuột trái đào và `R` hoặc chuột phải đặt khối. Bấm `E` để tương tác, ăn quả rừng, uống nước ở bờ hoặc mở chế tác; chọn ô nhanh bằng `1–9`; `Esc` để tạm dừng.

Trên điện thoại: cần điều khiển bên trái để đi, kéo phía phải để nhìn, các nút nổi để tương tác/đào/đặt/nhảy và chạm vật phẩm trong thanh công cụ.

## Mục tiêu chuyến đi

Gom gỗ và đá trước khi trời tối, chế tạo ván và lửa trại, dựng chỗ trú ẩn, ăn quả khi đói và tìm bờ biển khi khát. Chết sẽ hồi sinh tại bãi cắm trại với chỉ số thấp hơn. Bản hiện tại là chơi một mình, tạo đảo khi tải mới; cài đặt trình duyệt được lưu cục bộ (hoặc chỉ trong phiên nếu chính sách trình duyệt chặn), còn tiến độ thế giới/trận chơi không lưu sau khi tải lại.

## Cấu trúc chính

| Đường dẫn | Vai trò |
| --- | --- |
| `src/game/voxel-world.ts` | Đảo voxel tạo theo seed, chia chunk, mặt mesh, ánh sáng ngày/đêm, va chạm và raycast khối |
| `src/game/survival-game.ts` | Di chuyển góc nhìn thứ nhất, đào/đặt, túi đồ, công thức chế tác, sinh tồn và Warden |
| `src/ui/survival-ui.ts` | Menu, HUD tiếng Việt, thanh vật phẩm, tạm dừng và chế tác |
| `src/ui/touch.ts` | Joystick/drag-look và điều khiển cảm ứng |
| `src/engine/input.ts` | Kết hợp phím, chuột và cảm ứng vào cùng trạng thái hành động; kéo chuột dự phòng khi chạy `file://` |
| `src/engine/assets.ts` | Bộ nạp GLTF/texture có cache và theo dõi tiến độ tải |
| `src/game/tuning.ts` | Tweak manager cho tham số có consumer thật, chỉ đăng ký trong Preview/dev |
| `scripts/build-single-html.mjs` | Bundle JS/CSS, nhúng font/favicon/Warden và xuất một HTML tự chứa |
| `blockwild.html` | File tải/mở trực tiếp; có kèm giấy phép Three.js và ManusCC0 trong template HTML |

Game hiện ghim `vi-VN`; multiplayer, backend và bảng xếp hạng trực tuyến không nằm trong phạm vi.

## Asset và giấy phép

Font ManusCC0 đi kèm thuộc CC0 1.0; xem `public/fonts/ManusCC0-LICENSE.txt`. Engine dùng Three.js theo MIT và Rapier theo Apache-2.0 (Rapier vẫn nằm trong scaffold nhưng controller sinh tồn hiện dùng collision voxel trực tiếp). Bản HTML standalone nhúng phần license của font và Three.js vào template HTML để có thể phân phối một tệp.
