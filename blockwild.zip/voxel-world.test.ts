import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { VoxelWorld } from '../src/game/voxel-world'

describe('seeded voxel world', () => {
  let world: VoxelWorld
  beforeAll(() => { world = new VoxelWorld(new THREE.Scene(), 7919) })
  afterAll(() => world.dispose())

  it('builds a clear, grounded start inside a solid island', () => {
    expect(world.blocks.size).toBeGreaterThan(1_000)
    expect(world.heightAt(world.spawn.x, world.spawn.z)).toBe(world.spawn.y)
    expect(world.get(0, Math.floor(world.spawn.y - 1), 0)).toBe('grass')
    expect(world.collidesAabb(world.spawn.x, world.spawn.y, world.spawn.z, 0.28, 1.68)).toBe(false)
    expect(world.collidesAabb(world.spawn.x, world.spawn.y - 0.25, world.spawn.z, 0.28, 1.68)).toBe(true)
    expect(world.heightAt(30, 0)).toBe(0)
  })

  it('raycasts the exact surface voxel under the reticle', () => {
    const origin = new THREE.Vector3(world.spawn.x, world.spawn.y + 4, world.spawn.z)
    const ray = new THREE.Raycaster(origin, new THREE.Vector3(0, -1, 0))
    const hit = world.cast(ray, 8)
    expect(hit?.type).toBe('grass')
    expect(hit?.normal.y).toBe(1)
    expect(hit?.y).toBe(Math.floor(world.spawn.y - 1))
  })

  it('removes hidden faces across a negative-to-zero chunk seam', () => {
    const indexCount = (): number => world.collidableMeshes.reduce((sum, mesh) => sum + (mesh.geometry.index?.count ?? 0), 0)
    const before = indexCount()
    expect(world.set(-1, 40, 0, 'wood')).toBe(true)
    expect(indexCount() - before).toBe(36)
    expect(world.set(0, 40, 0, 'wood')).toBe(true)
    expect(indexCount() - before).toBe(60)
    expect(world.set(-1, 40, 0, null)).toBe(true)
    expect(indexCount() - before).toBe(36)
    expect(world.set(0, 40, 0, null)).toBe(true)
    expect(indexCount()).toBe(before)
    expect(world.get(-1, 40, 0)).toBeUndefined()
    expect(world.set(-1.5, 40, 0, 'wood')).toBe(false)
  })

  it('generates an obvious starter grove within practical walking distance', () => {
    const nearSpawnLogs = [...world.blocks.entries()].filter(([key, type]) => {
      const [x, y, z] = key.split(',').map(Number)
      return type === 'log' && Math.hypot(x - world.spawn.x, z - world.spawn.z) <= 12 && y >= world.spawn.y
    })
    const leaves = [...world.blocks.values()].filter(type => type === 'leaves')
    expect(nearSpawnLogs.length).toBeGreaterThanOrEqual(3)
    expect(leaves.length).toBeGreaterThan(120)
  })

  it('fells a connected tree only from its bottom log and removes every static log/leaf voxel', () => {
    const tree = new VoxelWorld(new THREE.Scene(), 314159)
    try {
      const rootEntry = [...tree.blocks.entries()].find(([key, type]) => {
        if (type !== 'log') return false
        const [x, y, z] = key.split(',').map(Number)
        return tree.get(x, y - 1, z) !== 'log'
      })
      expect(rootEntry).toBeDefined()
      const [rx, ry, rz] = rootEntry![0].split(',').map(Number)
      const topY = ry + 2
      expect(tree.get(rx, topY, rz)).toBe('log')
      expect(tree.fellTree(rx, topY, rz, new THREE.Vector3(1, 0, 0))).toBe(0)
      expect(tree.get(rx, topY, rz)).toBe('log')
      const beforeLogs = [...tree.blocks.values()].filter(type => type === 'log').length
      const felled = tree.fellTree(rx, ry, rz, new THREE.Vector3(0, 0, 1))
      expect(felled).toBeGreaterThanOrEqual(3)
      expect([...tree.blocks.values()].filter(type => type === 'log').length).toBe(beforeLogs - felled)
      expect(tree.get(rx, ry, rz)).toBeUndefined()
      const detached = tree.meshGroup.children.filter(child => child instanceof THREE.Group)
      expect(detached.length).toBeGreaterThan(0)
      expect(tree.collidesAabb(rx + 0.5, ry, rz + 0.5, 0.2, 1)).toBe(false)
      tree.update(0.3, 0.3)
      expect((detached[0] as THREE.Group).rotation.x !== 0 || (detached[0] as THREE.Group).rotation.z !== 0).toBe(true)
      tree.update(10, 10)
      expect(tree.meshGroup.children.filter(child => child instanceof THREE.Group)).toHaveLength(0)
    } finally { tree.dispose() }
  })

  it('does not topple a neighboring trunk whose leaves touch the first canopy', () => {
    const grove = new VoxelWorld(new THREE.Scene(), 2718)
    try {
      const groundY = 30, z = 30
      const additions: { x: number; y: number; z: number; type: 'grass' | 'log' | 'leaves' }[] = []
      for (const x of [20, 25]) {
        additions.push({ x, y: groundY - 1, z, type: 'grass' })
        for (let dy = 0; dy < 4; dy++) additions.push({ x, y: groundY + dy, z, type: 'log' })
      }
      // Canopies touch at x=22/23 but the adjacent tree's trunk remains independent.
      additions.push({ x: 22, y: groundY + 3, z, type: 'leaves' })
      additions.push({ x: 23, y: groundY + 3, z, type: 'leaves' })
      grove.setBatch(additions)
      expect(grove.fellTree(20, groundY, z, new THREE.Vector3(1, 0, 0))).toBe(4)
      expect(grove.get(20, groundY, z)).toBeUndefined()
      expect(grove.get(25, groundY, z)).toBe('log')
      expect(grove.get(25, groundY + 1, z)).toBe('log')
    } finally { grove.dispose() }
  })
})
