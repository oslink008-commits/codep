// End-to-end regression for Blockwild after `pnpm build`; screenshots stay in ignored ./shots/.
// Locally stage registered CDN inputs into dist/ only for this smoke server; build output stays CDN-backed.
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs'
import { dirname, resolve, sep } from 'node:path'
import { spawn } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { chromium } from 'playwright'

const port = 4300 + Math.floor(Math.random() * 500)
const url = `http://127.0.0.1:${port}/`
const out = process.env.SHOTS_DIR ?? 'shots'
const dist = resolve('dist')
mkdirSync(out, { recursive: true })

function stageRegisteredAssets() {
  const lock = JSON.parse(readFileSync('assets.lock.json', 'utf8'))
  for (const [source, asset] of Object.entries(lock.assets ?? {})) {
    if (!source.startsWith('assets/') || !asset.path?.startsWith('/manus-storage/game/sha256/')) continue
    if (!existsSync(source)) throw new Error(`registered asset is missing locally: ${source}`)
    const target = resolve(dist, `.${asset.path}`)
    if (!target.startsWith(`${dist}${sep}`)) throw new Error(`unsafe managed asset path: ${asset.path}`)
    mkdirSync(dirname(target), { recursive: true })
    copyFileSync(source, target)
  }
}

stageRegisteredAssets()
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(port), '--strictPort', '--host', '127.0.0.1'], { stdio: 'ignore', detached: false })
let browser
let diagnosticPage
const guard = setTimeout(() => fail('timed out'), 120_000)

function cleanup() {
  clearTimeout(guard)
  try { server.kill('SIGTERM') } catch {}
}
async function fail(message) {
  console.error(`smoke: FAIL — ${message}`)
  await browser?.close().catch(() => {})
  cleanup()
  process.exit(1)
}
async function waitForServer() {
  for (let i = 0; i < 60; i += 1) {
    try { if ((await fetch(url)).ok) return } catch {}
    await new Promise(resolve => setTimeout(resolve, 250))
  }
  throw new Error('preview server did not start')
}
async function openGame(context, errors) {
  const page = await context.newPage()
  diagnosticPage = page
  page.on('console', message => message.type() === 'error' && errors.push(message.text()))
  page.on('pageerror', error => errors.push(String(error)))
  page.on('response', response => response.status() >= 400 && errors.push(`HTTP ${response.status()} ${response.url()}`))
  await page.goto(url)
  await page.waitForSelector('[data-screen="title"].is-active', { timeout: 45_000 })
  await page.waitForFunction(() => Boolean(window.__game?.game), { timeout: 45_000 })
  await page.evaluate(async () => {
    await document.fonts.ready
    if (document.documentElement.lang !== 'vi-VN') throw new Error(`expected vi-VN, got ${document.documentElement.lang}`)
    for (const selector of ['.survival-title h1', '.survival-tagline']) {
      const family = getComputedStyle(document.querySelector(selector)).fontFamily
      if (!family.startsWith('ManusCC0')) throw new Error(`Unexpected game font: ${family}`)
    }
    if (![...document.fonts].some(face => face.family.replaceAll('"', '').replaceAll("'", '') === 'ManusCC0' && face.status === 'loaded')) {
      throw new Error('Bundled game font did not load')
    }
    const game = window.__game.game
    if (!game.world.blocks.size) throw new Error('voxel world is empty')
    if (!game.enemy?.isGroup || !game.enemyWalk) throw new Error('the rigged Warden or walk animation did not load')
  })
  await page.waitForTimeout(300)
  return page
}
const state = page => page.evaluate(() => {
  const game = window.__game.game
  const snapshot = game.snapshot()
  const enemy = game.enemy
  const action = game.enemyWalk
  return {
    mode: game.mode,
    elapsed: game.elapsed,
    timeOfDay: game.timeOfDay,
    position: { x: game.position.x, y: game.position.y, z: game.position.z },
    health: snapshot.health,
    hunger: snapshot.hunger,
    thirst: snapshot.thirst,
    selected: snapshot.selected,
    targetName: snapshot.targetName,
    targetType: game.target?.type ?? '',
    targetCoords: game.target ? [game.target.x, game.target.y, game.target.z] : null,
    targetNormal: game.target?.normal ? [game.target.normal.x, game.target.normal.y, game.target.normal.z] : null,
    blocks: game.world.blocks.size,
    inventory: { ...game.inventory },
    enemy: enemy ? { x: enemy.position.x, y: enemy.position.y, z: enemy.position.z } : null,
    walkTime: action?.time ?? 0,
    walkDuration: action?.getClip?.().duration ?? 0,
    walkScale: action?.timeScale ?? 0,
  }
})
const assert = (condition, message) => { if (!condition) throw new Error(message) }
async function expectVisible(page, selector, stage) {
  try { await page.waitForSelector(selector, { timeout: 6_000 }) }
  catch {
    const details = await page.evaluate(() => {
      const game = window.__game?.game
      return {
        screen: document.getElementById('ui')?.dataset.survivalScreen,
        drawer: document.querySelector('.survival-craft-drawer')?.className,
        mode: game?.mode,
        pointerLock: document.pointerLockElement?.id ?? null,
        interactHeld: game?.input?.held?.('interact') ?? null,
        target: game?.snapshot?.().targetName ?? null,
        position: game?.position?.toArray?.() ?? null,
      }
    })
    throw new Error(`${stage} timed out: ${selector}; state=${JSON.stringify(details)}`)
  }
}

try {
  await waitForServer()
  // Use the preinstalled Sandbox browser when Playwright's optional browser download is absent.
  const executablePath = process.env.CHROME_PATH
    ?? ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync)
  const args = ['--no-sandbox', '--disable-dev-shm-usage', '--ignore-gpu-blocklist']
  browser = await chromium.launch({ ...(executablePath ? { executablePath } : {}), args })
  const errors = []

  const desktopContext = await browser.newContext({ viewport: { width: 1280, height: 720 }, locale: 'en-US' })
  const desktop = await openGame(desktopContext, errors)
  await desktop.screenshot({ path: `${out}/01-title-vi.png` })

  await desktop.click('[data-action="start"]')
  await desktop.waitForSelector('[data-screen="playing"].is-active')
  const initial = await state(desktop)
  const hud = await desktop.evaluate(() => {
    const panel = document.querySelector('.survival-status')
    const rect = element => {
      if (!element) return null
      const { x, y, width, height } = element.getBoundingClientRect()
      return { x, y, width, height }
    }
    return {
      panel: rect(panel),
      health: rect(panel?.querySelector('.meter-health .survival-meter') ?? null),
      hunger: rect(panel?.querySelector('.meter-hunger .survival-meter') ?? null),
      text: panel?.textContent ?? '',
    }
  })
  assert(hud.panel && hud.panel.width >= 250, `survival HUD is too small to notice: ${JSON.stringify(hud.panel)}`)
  assert(hud.health && hud.health.height >= 8 && hud.hunger && hud.hunger.height >= 8, `health/hunger bars are too thin: ${JSON.stringify(hud)}`)
  assert(hud.text.includes('Máu') && hud.text.includes('Đói'), 'survival HUD does not label health and hunger in Vietnamese')
  const forest = await desktop.evaluate(() => {
    const game = window.__game.game
    let leaves = 0
    let nearbyTrunks = 0
    for (const [key, type] of game.world.blocks) {
      if (type === 'leaves') leaves += 1
      if (type !== 'log') continue
      const [x, , z] = key.split(',').map(Number)
      if (Math.hypot(x + 0.5 - game.world.spawn.x, z + 0.5 - game.world.spawn.z) < 10) nearbyTrunks += 1
    }
    return { leaves, nearbyTrunks }
  })
  assert(forest.leaves > 100 && forest.nearbyTrunks >= 8, `forest is not visible around spawn: ${JSON.stringify(forest)}`)
  await desktop.waitForTimeout(2800)
  const hand = await desktop.evaluate(() => {
    const game = window.__game.game
    const p = game.forearm.position.clone().project(game.camera)
    return { visible: game.forearm.visible, parts: game.forearm.children.length, x: p.x, y: p.y }
  })
  assert(hand.visible && hand.parts >= 6 && Math.abs(hand.x) < 0.95 && Math.abs(hand.y) < 0.95, `voxel hand is missing/outside the view: ${JSON.stringify(hand)}`)
  await desktop.screenshot({ path: `${out}/02-forest-hud-hand.png` })
  assert(initial.mode === 'playing', `expected playing, got ${initial.mode}`)
  assert(initial.blocks > 1000, `unexpected voxel count ${initial.blocks}`)

  // Fixed-step jump and keyboard movement.
  await desktop.keyboard.press('Space')
  await desktop.waitForTimeout(140)
  const airborne = await state(desktop)
  assert(airborne.position.y > initial.position.y + 0.25, 'jump did not lift the player')
  await desktop.waitForTimeout(600)
  await desktop.keyboard.down('w')
  await desktop.waitForTimeout(750)
  await desktop.keyboard.up('w')
  await desktop.waitForTimeout(100)
  const moved = await state(desktop)
  const distance = Math.hypot(moved.position.x - initial.position.x, moved.position.z - initial.position.z)
  assert(distance > 0.7, `player barely moved (${distance.toFixed(2)} m)`)
  assert(moved.elapsed > initial.elapsed + 1, 'survival clock did not advance')
  assert(moved.hunger < initial.hunger, 'hunger did not decrease during play')

  // Aim at a neighboring top face and place a block with the real desktop key/raycast.
  await desktop.evaluate(() => {
    const game = window.__game.game
    window.__game.input.takeLook()
    game.position.copy(game.world.spawn)
    game.velocity.set(0, 0, 0)
    game.selectSlot(0)
    game.yaw = -Math.PI / 2
    game.pitch = -Math.atan(0.75)
    game.render(0, 1 / 60)
  })
  await desktop.waitForFunction(() => {
    const game = window.__game.game
    return game.target?.x === 2 && game.target?.y === Math.floor(game.world.spawn.y) - 1 && game.target?.z === 0
  }, { timeout: 3000 })
  const placeAim = await state(desktop)
  assert(placeAim.targetNormal?.[1] === 1, `placement reticle missed the top face: ${JSON.stringify(placeAim)}`)
  await desktop.keyboard.press('r')
  await desktop.waitForFunction(() => {
    const game = window.__game.game
    return game.world.get(2, Math.floor(game.world.spawn.y), 0) === 'dirt'
  }, { timeout: 3000 })
  const placed = await state(desktop)
  assert(placed.inventory.dirt === placeAim.inventory.dirt - 1, 'placing a dirt voxel did not consume one item')

  // Aim at the starting column, mine with the desktop key, and verify the voxel is removed.
  await desktop.evaluate(() => {
    const game = window.__game.game
    game.position.copy(game.world.spawn)
    game.velocity.set(0, 0, 0)
    game.yaw = 0
    game.pitch = -1.18
    game.render(0, 1 / 60)
  })
  await desktop.waitForFunction(() => Boolean(window.__game.game.target), { timeout: 3000 })
  const aim = await state(desktop)
  assert(aim.targetType && !['water', 'bedrock'].includes(aim.targetType), `crosshair did not select a mineable block (${aim.targetName})`)
  await desktop.keyboard.down('f')
  await desktop.waitForTimeout(520)
  await desktop.keyboard.up('f')
  await desktop.waitForTimeout(120)
  const mined = await state(desktop)
  assert(mined.blocks < aim.blocks, 'F did not mine a voxel')

  // Craft planks and a table using the live recipe UI.
  await desktop.keyboard.press('e')
  await expectVisible(desktop, '.survival-craft-drawer.is-open', 'desktop E crafting')
  assert((await state(desktop)).mode === 'playing', 'opening crafting paused the survival session')
  await desktop.click('[data-recipe="planks"]')
  assert((await state(desktop)).inventory.planks === 8, 'planks recipe did not consume wood and produce four planks')
  await desktop.click('[data-recipe="crafting_table"]')
  const crafted = await state(desktop)
  assert(crafted.inventory.crafting_table === 1 && crafted.inventory.planks === 4, 'crafting-table recipe failed')
  await desktop.click('[data-action="craft-close"]')

  // Eat a berry from the hotbar to restore hunger.
  await desktop.keyboard.press('5')
  await desktop.waitForTimeout(80)
  const beforeFood = await state(desktop)
  await desktop.keyboard.press('e')
  await desktop.waitForTimeout(120)
  const afterFood = await state(desktop)
  assert(afterFood.hunger > beforeFood.hunger && afterFood.inventory.berries < beforeFood.inventory.berries, 'berry interaction did not restore hunger')

  // Exercise the held-mine action on a real starter root and verify its gravity-driven topple.
  const rootTree = await desktop.evaluate(() => {
    const game = window.__game.game
    const root = [...game.world.blocks.entries()].flatMap(([key, type]) => {
      if (type !== 'log') return []
      const [x, y, z] = key.split(',').map(Number)
      if (game.world.get(x, y - 1, z) === 'log') return []
      const distance = Math.hypot(x + 0.5 - game.world.spawn.x, z + 0.5 - game.world.spawn.z)
      return distance < 11 ? [{ x, y, z, distance }] : []
    }).sort((a, b) => a.distance - b.distance)[0]
    if (!root) throw new Error('no starter tree root')
    game.position.copy(game.world.spawn)
    game.velocity.set(0, 0, 0)
    game.input.takeLook()
    const dx = root.x + 0.5 - game.position.x
    const dz = root.z + 0.5 - game.position.z
    const distance = Math.hypot(dx, dz)
    game.yaw = Math.atan2(-dx, -dz)
    game.pitch = Math.atan2(root.y + 0.15 - (game.position.y + 1.55), distance)
    game.render(0, 1 / 60)
    game.target = { x: root.x, y: root.y, z: root.z, type: 'log' }
    return root
  })
  const logsBeforeFelling = (await state(desktop)).inventory.wood
  await desktop.evaluate(({ x, y, z }) => {
    const game = window.__game.game
    game.target = { x, y, z, type: 'log' }
    game.mineBlock(0.75)
  }, rootTree)
  const felling = await desktop.evaluate(({ x, y, z }) => ({
    root: window.__game.game.world.get(x, y, z) ?? null,
    groups: window.__game.game.world.meshGroup.children.filter(child => child.type === 'Group').length,
    wood: window.__game.game.inventory.wood,
  }), rootTree)
  assert(felling.root === null && felling.groups > 0, `root mining did not start a tree topple: ${JSON.stringify(felling)}`)
  assert(felling.wood > logsBeforeFelling, 'chopping a root did not award wood')
  await desktop.waitForTimeout(260)
  await desktop.screenshot({ path: `${out}/03-tree-felling.png` })
  await desktop.waitForTimeout(1650)
  const afterTopple = await desktop.evaluate(() => window.__game.game.world.meshGroup.children.filter(child => child.type === 'Group').length)
  assert(afterTopple === 0, 'felled tree remained suspended instead of completing its topple/cleanup')

  // Put the creature into night conditions and play its seamless in-place walk clip in view.
  await desktop.evaluate(() => {
    const game = window.__game.game
    game.elapsed = 220
    const dx = game.enemy.position.x - game.position.x
    const dz = game.enemy.position.z - game.position.z
    game.yaw = Math.atan2(-dx, -dz)
    game.pitch = 0.03
  })
  const beforeWalk = await state(desktop)
  await desktop.waitForTimeout(1100)
  const afterWalk = await state(desktop)
  const wardenTravel = Math.hypot(afterWalk.enemy.x - beforeWalk.enemy.x, afterWalk.enemy.z - beforeWalk.enemy.z)
  await desktop.screenshot({ path: `${out}/02-night-warden.png` })
  assert(wardenTravel > 0.35, `Warden did not approach at night (${wardenTravel.toFixed(2)} m)`)
  assert(afterWalk.walkScale === 1, `Warden walk did not activate: before=${JSON.stringify(beforeWalk)} after=${JSON.stringify(afterWalk)}`)

  await desktop.keyboard.press('Escape')
  await desktop.waitForSelector('[data-screen="paused"].is-active')
  await desktop.screenshot({ path: `${out}/03-pause.png` })
  assert((await state(desktop)).mode === 'paused', 'pause transition failed')
  await desktopContext.close()

  const phoneContext = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'vi-VN' })
  const phone = await openGame(phoneContext, errors)
  assert(await phone.locator('.survival-title-note-touch').isVisible(), 'mobile title does not show touch controls')
  await phone.tap('[data-action="start"]')
  await phone.waitForSelector('[data-screen="playing"].is-active')
  assert(await phone.locator('.survival-touch-actions button[data-touch="jump"]').isVisible(), 'mobile action buttons are missing')
  await phone.waitForTimeout(80)
  const phoneHud = await phone.evaluate(() => {
    const panel = document.querySelector('.survival-status')?.getBoundingClientRect()
    const day = document.querySelector('.survival-day')?.getBoundingClientRect()
    const game = window.__game.game
    const handPoint = game.forearm.position.clone().project(game.camera)
    return {
      panel: panel ? { x: panel.x, right: panel.right, width: panel.width } : null,
      day: day ? { x: day.x } : null,
      health: document.querySelector('.meter-health .survival-meter')?.getBoundingClientRect().height ?? 0,
      hunger: document.querySelector('.meter-hunger .survival-meter')?.getBoundingClientRect().height ?? 0,
      labels: document.querySelector('.survival-status')?.textContent ?? '',
      hand: { visible: game.forearm.visible, x: handPoint.x, y: handPoint.y },
    }
  })
  assert(phoneHud.panel && phoneHud.panel.width >= 160, `mobile survival HUD is too small: ${JSON.stringify(phoneHud)}`)
  assert(phoneHud.day && phoneHud.panel.right < phoneHud.day.x, `mobile survival HUD overlaps the day panel: ${JSON.stringify(phoneHud)}`)
  assert(phoneHud.health >= 6 && phoneHud.hunger >= 6 && phoneHud.labels.includes('Máu') && phoneHud.labels.includes('Đói'), `mobile health/hunger bars are not visible: ${JSON.stringify(phoneHud)}`)
  assert(phoneHud.hand.visible && Math.abs(phoneHud.hand.x) < 0.95 && Math.abs(phoneHud.hand.y) < 0.95, `voxel hand is not visible on mobile: ${JSON.stringify(phoneHud.hand)}`)
  const phoneStart = await state(phone)
  await phone.tap('[data-touch="jump"]')
  await phone.waitForTimeout(110)
  const phoneJump = await state(phone)
  assert(phoneJump.position.y > phoneStart.position.y + 0.2, 'touch jump did not lift the player')
  await phone.tap('[data-touch="interact"]')
  await expectVisible(phone, '.survival-craft-drawer.is-open', 'mobile touch interact')
  await phone.screenshot({ path: `${out}/04-phone-crafting.png` })
  await phone.tap('[data-action="craft-close"]')
  await phone.waitForTimeout(200)
  assert((await state(phone)).mode === 'playing', 'closing the mobile craft drawer left the session')
  await phoneContext.close()

  // Open the exported HTML from disk: every runtime dependency must be embedded and local.
  const singleContext = await browser.newContext({ viewport: { width: 1280, height: 720 }, locale: 'vi-VN' })
  const single = await singleContext.newPage()
  const singleErrors = []
  const externalRequests = []
  single.on('console', message => message.type() === 'error' && singleErrors.push(message.text()))
  single.on('pageerror', error => singleErrors.push(String(error)))
  single.on('request', request => /^https?:/i.test(request.url()) && externalRequests.push(request.url()))
  await single.goto(pathToFileURL(resolve('blockwild.html')).href)
  await single.waitForSelector('[data-screen="title"].is-active', { timeout: 45_000 })
  await single.waitForFunction(() => Boolean(window.__game?.game?.enemyWalk), { timeout: 45_000 })
  await single.evaluate(async () => {
    await document.fonts.ready
    if (![...document.fonts].some(face => face.family.replaceAll('"', '').replaceAll("'", '') === 'ManusCC0' && face.status === 'loaded')) {
      throw new Error('The standalone HTML font was not embedded.')
    }
    const game = window.__game.game
    if (!game.world.blocks.size || !game.enemyWalk) throw new Error('Standalone voxel world or Warden is missing.')
  })
  await single.click('[data-action="start"]')
  await single.waitForSelector('[data-screen="playing"].is-active')
  assert((await single.evaluate(() => window.__game.game.mode)) === 'playing', 'standalone game did not enter play mode')
  // The local-file fallback must still let desktop players rotate the camera by dragging.
  await single.evaluate(() => window.__game.input.unlockPointer())
  await single.waitForTimeout(80)
  const box = await single.locator('#game').boundingBox()
  assert(box, 'standalone canvas has no bounds')
  const yawBefore = await single.evaluate(() => window.__game.game.yaw)
  await single.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
  await single.mouse.down()
  await single.mouse.move(box.x + box.width / 2 + 70, box.y + box.height / 2 + 18, { steps: 5 })
  await single.mouse.up()
  await single.evaluate(() => window.__game.input.unlockPointer())
  await single.waitForTimeout(100)
  const yawAfter = await single.evaluate(() => window.__game.game.yaw)
  assert(Math.abs(yawAfter - yawBefore) > 0.04, 'file:// mouse-drag camera fallback did not respond')
  const externalResources = await single.evaluate(() => performance.getEntriesByType('resource').map(entry => entry.name).filter(url => /^https?:/i.test(url)))
  assert(externalRequests.length === 0 && externalResources.length === 0, `standalone HTML made network requests: ${[...externalRequests, ...externalResources].join(', ')}`)
  if (singleErrors.length) throw new Error(`standalone file:// console/page errors:\n  ${singleErrors.join('\n  ')}`)
  await singleContext.close()

  if (errors.length) throw new Error(`console/page/network errors:\n  ${errors.join('\n  ')}`)
  await browser.close()
  cleanup()
  console.log(`smoke: OK — desktop/mobile survival, voxel placement/mining, crafting, night Warden, pause, plus self-contained offline file:// HTML; screenshots in ${out}/`)
} catch (error) {
  await fail(error?.message ?? String(error))
}
