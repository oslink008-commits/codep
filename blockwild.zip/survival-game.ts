import * as THREE from 'three'
import type { Audio } from '../engine/audio'
import type { Input } from '../engine/input'
import type { Renderer } from '../engine/renderer'
import { CONFIG } from './config'
import { tuning } from './tuning'
import { VoxelWorld, type BlockHit, type BlockType } from './voxel-world'

export type SurvivalMode = 'title' | 'playing' | 'paused'
export type ItemType = BlockType | 'berries'
export type InventoryItem = { type: string; name: string; count: number }
export type SurvivalSnapshot = {
  health: number
  hunger: number
  thirst: number
  day: number
  clock: string
  inventory: InventoryItem[]
  selected: number
  toast: string
  targetName: string
}
export type SurvivalHooks = {
  toast(message: string): void
  openCraft(): void
}

const HOTBAR: ItemType[] = ['dirt', 'wood', 'stone', 'planks', 'berries', 'torch', 'campfire', 'crafting_table', 'coal']
const ITEM_NAMES: Record<ItemType, string> = {
  grass: 'Cỏ', dirt: 'Đất', stone: 'Đá', log: 'Thân cây', leaves: 'Lá', sand: 'Cát', wood: 'Gỗ', coal: 'Than', iron: 'Quặng sắt',
  planks: 'Ván gỗ', crafting_table: 'Bàn chế tạo', campfire: 'Lửa trại', torch: 'Đuốc', water: 'Nước', bedrock: 'Đá nền', berries: 'Quả rừng',
}
const PLACEABLE = new Set<ItemType>(['dirt', 'wood', 'stone', 'planks', 'torch', 'campfire', 'crafting_table'])
const PLAYER_HALF = 0.28
const PLAYER_HEIGHT = 1.68
const EYE_HEIGHT = 1.5

/** A self-contained first-person voxel survival session; engine input, renderer and Tweak stay shared. */
export class SurvivalGame {
  mode: SurvivalMode = 'title'
  reducedMotion = false
  readonly world: VoxelWorld
  readonly camera = new THREE.PerspectiveCamera(76, 1, 0.06, 180)
  readonly position: THREE.Vector3
  readonly velocity = new THREE.Vector3()
  readonly inventory: Record<string, number> = {
    dirt: 8, wood: 2, stone: 2, planks: 4, berries: 2, torch: 2, campfire: 0, crafting_table: 0,
  }
  health = 100
  hunger = 82
  thirst = 78
  selected = 0
  elapsed = 0
  private yaw = 0
  private pitch = -0.18
  private miningKey = ''
  private miningProgress = 0
  private target: BlockHit | null = null
  private readonly forearm = new THREE.Group()
  private readonly handParts: THREE.Mesh[] = []
  private miningSwing = 0
  private readonly handGeometry = new THREE.BoxGeometry(1, 1, 1)
  private readonly handMaterials = [new THREE.MeshStandardMaterial({ color: '#8a5a3c', roughness: 0.85 }), new THREE.MeshStandardMaterial({ color: '#b47a53', roughness: 0.85 })]
  private readonly raycaster = new THREE.Raycaster()
  private readonly aim = new THREE.Vector2(0, 0)
  private toastValue = ''
  private toastTime = 0
  private needDamageClock = 0
  private savePulse = 0
  private campfireHealClock = 0
  private readonly enemy?: THREE.Group
  private readonly enemyMixer?: THREE.AnimationMixer
  private readonly enemyWalk?: THREE.AnimationAction
  private readonly enemyGlow?: THREE.PointLight
  private readonly enemyGlowMaterials = new Set<THREE.MeshStandardMaterial>()
  private enemyAttack = 0
  private timeOfDay = 0.34
  private lastSfxAt = 0

  constructor(
    private readonly renderer: Renderer,
    private readonly input: Input,
    private readonly audio: Audio,
    private readonly hooks: SurvivalHooks,
    enemyAsset?: { scene: THREE.Object3D; animations?: THREE.AnimationClip[] },
  ) {
    this.world = new VoxelWorld()
    this.position = this.world.spawn.clone()
    this.camera.fov = CONFIG.camera.fov
    this.camera.rotation.order = 'YXZ'
    this.camera.updateProjectionMatrix()
    if (enemyAsset) {
      const model = enemyAsset.scene as THREE.Group
      const bounds = new THREE.Box3().setFromObject(model)
      const sourceHeight = Math.max(0.01, bounds.max.y - bounds.min.y)
      const scale = 2.15 / sourceHeight
      model.scale.setScalar(scale)
      model.traverse(o => {
        if (!(o instanceof THREE.Mesh)) return
        o.castShadow = true
        o.receiveShadow = true
        for (const material of Array.isArray(o.material) ? o.material : [o.material]) {
          if (material instanceof THREE.MeshStandardMaterial) {
            material.emissive.set('#276d49')
            material.emissiveIntensity = 0
            this.enemyGlowMaterials.add(material)
          }
        }
      })
      const x = this.position.x + 12
      const z = this.position.z + 8
      model.position.set(x, this.world.surfaceAt(x, z) - bounds.min.y * scale, z)
      model.rotation.y = Math.atan2(this.position.x - x, this.position.z - z)
      this.world.scene.add(model)
      this.enemy = model
      this.enemyGlow = new THREE.PointLight('#8de5b3', 0, 8, 2)
      this.enemyGlow.position.set(x, model.position.y + 1.25, z)
      this.world.scene.add(this.enemyGlow)
      if (enemyAsset.animations?.length) {
        this.enemyMixer = new THREE.AnimationMixer(model)
        const walk = enemyAsset.animations.find(c => /walk|run|locomotion/i.test(c.name)) ?? enemyAsset.animations[0]
        this.enemyWalk = this.enemyMixer.clipAction(walk)
        this.enemyWalk.setLoop(THREE.LoopRepeat, Infinity)
        this.enemyWalk.timeScale = 0.08
        this.enemyWalk.play()
      }
    }
    this.buildForearm()
    this.camera.position.copy(this.position).add(new THREE.Vector3(0, EYE_HEIGHT, 0))
    this.camera.lookAt(this.camera.position.clone().add(new THREE.Vector3(0, 0, -1)))
  }

  start(): void {
    tuning.activate('run')
    this.mode = 'playing'
    this.input.endFrame()
    this.input.takeLook()
    this.toast('Chặt cây, gom đá và dựng nơi trú trước khi trời tối.')
  }

  pause(): void { if (this.mode === 'playing') this.mode = 'paused' }
  resume(): void { if (this.mode === 'paused') { this.mode = 'playing'; this.input.endFrame(); this.input.takeLook() } }
  toTitle(): void { this.mode = 'title'; this.input.takeLook() }

  selectSlot(index: number): void {
    this.selected = THREE.MathUtils.clamp(Math.floor(index), 0, HOTBAR.length - 1)
  }

  interact(): void {
    const selected = HOTBAR[this.selected]
    if (selected === 'berries' && (this.inventory.berries ?? 0) > 0) {
      this.inventory.berries -= 1
      this.hunger = Math.min(100, this.hunger + 24)
      this.health = Math.min(100, this.health + 4)
      this.toast('Bạn ăn quả rừng. Cơn đói dịu lại.')
      this.audio.play('pickup')
      return
    }
    if (this.target?.type === 'water') {
      this.thirst = Math.min(100, this.thirst + 38)
      this.toast('Bạn uống nước suối mát lành.')
      this.audio.play('pickup')
      return
    }
    if (Math.abs(this.position.x) > 24 || Math.abs(this.position.z) > 24 || this.world.heightAt(this.position.x, this.position.z) <= 4) {
      this.thirst = Math.min(100, this.thirst + 38)
      this.toast('Bạn uống nước bên bờ biển.')
      this.audio.play('pickup')
      return
    }
    this.hooks.openCraft()
  }

  craft(recipe: string): boolean {
    const recipes: Record<string, { takes: Record<string, number>; makes: ItemType; amount: number; label: string }> = {
      planks: { takes: { wood: 1 }, makes: 'planks', amount: 4, label: '4 ván gỗ' },
      crafting_table: { takes: { planks: 4 }, makes: 'crafting_table', amount: 1, label: 'bàn chế tạo' },
      campfire: { takes: { wood: 3, stone: 2 }, makes: 'campfire', amount: 1, label: 'lửa trại' },
      torch: { takes: { wood: 1, coal: 1 }, makes: 'torch', amount: 4, label: '4 ngọn đuốc' },
    }
    const selectedRecipe = recipes[recipe]
    if (!selectedRecipe) return false
    for (const [type, count] of Object.entries(selectedRecipe.takes)) {
      if ((this.inventory[type] ?? 0) < count) {
        this.toast(`Thiếu ${ITEM_NAMES[type as ItemType].toLowerCase()}.`)
        this.audio.play('ui')
        return false
      }
    }
    for (const [type, count] of Object.entries(selectedRecipe.takes)) this.inventory[type] = (this.inventory[type] ?? 0) - count
    this.inventory[selectedRecipe.makes] = (this.inventory[selectedRecipe.makes] ?? 0) + selectedRecipe.amount
    this.toast(`Đã chế tạo ${selectedRecipe.label}.`)
    this.audio.play('pickup')
    return true
  }

  step(dt: number): void {
    if (this.mode !== 'playing') {
      this.input.consume('jump'); this.input.consume('interact'); this.input.consume('place')
      return
    }
    this.elapsed += dt
    this.timeOfDay = (0.34 + this.elapsed / 480) % 1
    this.world.update(this.timeOfDay, dt)
    this.miningSwing = Math.max(0, this.miningSwing - dt * 5.5)
    this.enemyMixer?.update(dt)
    this.enemyAttack = Math.max(0, this.enemyAttack - dt)

    if (this.input.consume('interact')) this.interact()
    if (this.input.consume('jump') && this.isGrounded()) {
      tuning.activate('jump')
      this.velocity.y = CONFIG.player.jumpSpeed
      this.audio.play('jump')
    }
    if (this.input.consume('place')) this.placeBlock()
    if (this.input.held('mine')) this.mineBlock(dt)
    else { this.miningKey = ''; this.miningProgress = 0 }

    const move = this.input.move
    const forwardX = -Math.sin(this.yaw)
    const forwardZ = -Math.cos(this.yaw)
    const rightX = Math.cos(this.yaw)
    const rightZ = -Math.sin(this.yaw)
    let mx = rightX * move.x + forwardX * move.y
    let mz = rightZ * move.x + forwardZ * move.y
    const length = Math.hypot(mx, mz)
    if (length > 1) { mx /= length; mz /= length }
    const speed = this.input.held('sprint') ? CONFIG.player.sprintSpeed : CONFIG.player.walkSpeed
    const acceleration = Math.min(1, CONFIG.player.acceleration * dt / Math.max(speed, 1))
    this.velocity.x += (mx * speed - this.velocity.x) * acceleration
    this.velocity.z += (mz * speed - this.velocity.z) * acceleration
    if (length < 0.01) { this.velocity.x *= Math.exp(-10 * dt); this.velocity.z *= Math.exp(-10 * dt) }

    const nextX = this.position.x + this.velocity.x * dt
    if (!this.world.collidesAabb(nextX, this.position.y, this.position.z, PLAYER_HALF, PLAYER_HEIGHT)) this.position.x = nextX
    else this.velocity.x = 0
    const nextZ = this.position.z + this.velocity.z * dt
    if (!this.world.collidesAabb(this.position.x, this.position.y, nextZ, PLAYER_HALF, PLAYER_HEIGHT)) this.position.z = nextZ
    else this.velocity.z = 0

    const floor = this.world.surfaceAt(this.position.x, this.position.z)
    const wasGrounded = Math.abs(this.position.y - floor) < 0.045
    this.velocity.y = Math.max(-26, this.velocity.y + CONFIG.player.gravity * dt)
    let nextY = this.position.y + this.velocity.y * dt
    if (this.velocity.y <= 0 && nextY <= floor) {
      nextY = floor
      if (!wasGrounded && this.velocity.y < -7) this.audio.play('land')
      this.velocity.y = 0
    } else if (this.world.collidesAabb(this.position.x, nextY, this.position.z, PLAYER_HALF, PLAYER_HEIGHT)) {
      nextY = this.position.y
      this.velocity.y = 0
    }
    this.position.y = nextY
    if (this.camera.fov !== CONFIG.camera.fov) {
      this.camera.fov = CONFIG.camera.fov
      this.camera.updateProjectionMatrix()
    }

    if (this.position.y < -12) {
      this.position.copy(this.world.spawn)
      this.velocity.set(0, 0, 0)
      this.health = Math.max(1, this.health - 22)
      this.toast('Bạn được đưa về khu rừng an toàn sau cú ngã.')
    }

    this.hunger = Math.max(0, this.hunger - dt * CONFIG.survival.hungerRate)
    this.thirst = Math.max(0, this.thirst - dt * CONFIG.survival.thirstRate)
    if (this.hunger <= 0 || this.thirst <= 0) {
      this.needDamageClock += dt
      if (this.needDamageClock >= 2.4) {
        this.needDamageClock = 0
        this.health = Math.max(0, this.health - 4)
        this.audio.play('hurt')
        this.toast(this.thirst <= 0 ? 'Cơ thể kiệt nước — tìm nguồn nước gần bờ biển.' : 'Bạn đang đói — dùng quả rừng trong ô vật phẩm.')
      }
    } else this.needDamageClock = 0

    this.updateCreature(dt)
    if (this.health <= 0) {
      this.position.copy(this.world.spawn)
      this.velocity.set(0, 0, 0)
      this.health = 45
      this.hunger = Math.max(12, this.hunger)
      this.thirst = Math.max(12, this.thirst)
      this.toast('Bạn tỉnh lại ở bãi cắm trại. Hãy chuẩn bị tốt hơn cho đêm sau.')
    }
    this.campfireHealClock += dt
    if (this.campfireHealClock > 1) {
      this.campfireHealClock = 0
      if (this.nearCampfire()) {
        this.health = Math.min(100, this.health + 1)
        this.hunger = Math.min(100, this.hunger + 0.2)
      }
    }
    this.toastTime = Math.max(0, this.toastTime - dt)
    this.savePulse += dt
  }

  render(_alpha: number, frameSeconds: number): void {
    if (this.mode === 'playing') {
      const look = this.input.takeLook()
      this.yaw -= look.x
      this.pitch = THREE.MathUtils.clamp(this.pitch + look.y, -1.25, 1.2)
      this.camera.position.set(this.position.x, this.position.y + EYE_HEIGHT, this.position.z)
      this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ')
      // Camera is intentionally not part of scene: place the visible arm in world space each frame.
      const handX = Math.min(0.46, 0.3 * Math.max(0.45, this.camera.aspect))
      const armOffset = new THREE.Vector3(handX, -0.08 - this.miningSwing * 0.1, -0.8).applyQuaternion(this.camera.quaternion)
      this.forearm.position.copy(this.camera.position).add(armOffset)
      this.forearm.quaternion.copy(this.camera.quaternion)
      this.raycaster.setFromCamera(this.aim, this.camera)
      this.target = this.world.cast(this.raycaster, 5.6)
    } else {
      this.target = null
      const t = performance.now() * 0.00006
      const focus = this.world.spawn.clone().add(new THREE.Vector3(0, 2, 0))
      this.camera.position.set(focus.x + Math.sin(t) * 21, focus.y + 12 + Math.sin(t * 0.7), focus.z + Math.cos(t) * 21)
      this.camera.lookAt(focus)
    }
    this.forearm.visible = this.mode === 'playing'
    this.renderer.render(this.world.scene, this.camera)
    if (this.mode === 'playing') this.lastSfxAt += frameSeconds
  }

  snapshot(): SurvivalSnapshot {
    const clockValue = (8 + this.elapsed / 20) % 24
    const hour = Math.floor(clockValue)
    const minute = Math.floor((clockValue - hour) * 60)
    const day = Math.floor((8 + this.elapsed / 20) / 24) + 1
    const inventory = HOTBAR.map(type => ({ type, name: ITEM_NAMES[type], count: this.inventory[type] ?? 0 }))
    return {
      health: this.health, hunger: this.hunger, thirst: this.thirst, day,
      clock: `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`,
      inventory, selected: this.selected, toast: this.toastTime > 0 ? this.toastValue : '',
      targetName: this.target ? ITEM_NAMES[this.target.type] : '',
    }
  }

  get activeItem(): ItemType { return HOTBAR[this.selected] }

  dispose(): void {
    this.world.scene.remove(this.forearm)
    this.handGeometry.dispose(); this.handMaterials.forEach(material => material.dispose())
    this.world.dispose()
  }
  private buildForearm(): void {
    const arm = new THREE.Mesh(this.handGeometry, this.handMaterials[0]); arm.scale.set(0.2, 0.62, 0.22); arm.position.set(0, -0.25, 0); this.forearm.add(arm); this.handParts.push(arm)
    const palm = new THREE.Mesh(this.handGeometry, this.handMaterials[1]); palm.scale.set(0.24, 0.23, 0.23); palm.position.set(0, -0.57, -0.02); this.forearm.add(palm); this.handParts.push(palm)
    for (let i = 0; i < 4; i++) { const finger = new THREE.Mesh(this.handGeometry, this.handMaterials[1]); finger.scale.set(0.045, 0.15, 0.07); finger.position.set(-0.075 + i * 0.05, -0.71, -0.025); this.forearm.add(finger); this.handParts.push(finger) }
    const thumb = new THREE.Mesh(this.handGeometry, this.handMaterials[1]); thumb.scale.set(0.07, 0.14, 0.08); thumb.position.set(0.14, -0.57, -0.04); thumb.rotation.z = -0.55; this.forearm.add(thumb); this.handParts.push(thumb)
    this.forearm.scale.setScalar(0.38)
    this.forearm.traverse(object => { if (object instanceof THREE.Mesh) { object.castShadow = true; object.renderOrder = 10 } })
    this.world.scene.add(this.forearm)
  }

  private isGrounded(): boolean {
    return this.position.y <= this.world.surfaceAt(this.position.x, this.position.z) + 0.045 && Math.abs(this.velocity.y) < 0.15
  }

  private mineBlock(dt: number): void {
    const hit = this.target
    if (!hit || hit.type === 'bedrock' || hit.type === 'water') { this.miningKey = ''; this.miningProgress = 0; return }
    const key = `${hit.x},${hit.y},${hit.z}`
    if (key !== this.miningKey) { this.miningKey = key; this.miningProgress = 0 }
    this.miningProgress += dt
    this.miningSwing = Math.max(this.miningSwing, 0.72)
    const duration = hit.type === 'stone' || hit.type === 'iron' || hit.type === 'coal' ? 1.05 : hit.type === 'log' ? 0.72 : 0.42
    if (this.miningProgress < duration) return
    // Let the trunk tip away from the player so the falling crown doesn't engulf the camera.
    const logs = hit.type === 'log' ? this.world.fellTree(hit.x, hit.y, hit.z, new THREE.Vector3(hit.x - this.position.x, 0, hit.z - this.position.z)) : 0
    if (!logs && !this.world.set(hit.x, hit.y, hit.z, null)) return
    const drop: ItemType = hit.type === 'log' ? 'wood' : hit.type === 'leaves' ? 'berries' : hit.type === 'grass' || hit.type === 'sand' ? 'dirt' : hit.type === 'iron' ? 'iron' : hit.type === 'coal' ? 'coal' : 'stone'
    const amount = logs || 1
    if (hit.type !== 'leaves') this.inventory[drop] = (this.inventory[drop] ?? 0) + amount
    else if (Math.random() < 0.38) this.inventory[drop] = (this.inventory[drop] ?? 0) + 1
    this.toast(`+${amount} ${ITEM_NAMES[drop]}`)
    if (this.lastSfxAt > 0.12) { this.audio.play('pickup'); this.lastSfxAt = 0 }
    this.miningKey = ''; this.miningProgress = 0
  }

  private placeBlock(): void {
    const hit = this.target
    const type = this.activeItem
    if (!hit || !PLACEABLE.has(type)) return
    const nx = Math.round(hit.normal.x)
    const ny = Math.round(hit.normal.y)
    const nz = Math.round(hit.normal.z)
    const x = hit.x + nx, y = hit.y + ny, z = hit.z + nz
    if ((this.inventory[type] ?? 0) <= 0) { this.toast(`Bạn không còn ${ITEM_NAMES[type].toLowerCase()}.`); return }
    const cx = x + 0.5, cy = y, cz = z + 0.5
    const bodyMinY = this.position.y, bodyMaxY = this.position.y + PLAYER_HEIGHT
    if (cx > this.position.x - PLAYER_HALF - 0.5 && cx < this.position.x + PLAYER_HALF + 0.5 && cz > this.position.z - PLAYER_HALF - 0.5 && cz < this.position.z + PLAYER_HALF + 0.5 && cy < bodyMaxY && cy + 1 > bodyMinY) {
      this.toast('Không thể đặt khối đè lên nhân vật.'); return
    }
    if (this.world.set(x, y, z, type as BlockType)) {
      this.inventory[type] -= 1
      this.audio.play('ui')
      this.toast(`Đã đặt ${ITEM_NAMES[type].toLowerCase()}.`)
    }
  }

  private nearCampfire(): boolean {
    const x = Math.floor(this.position.x), z = Math.floor(this.position.z)
    for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) for (let dy = -1; dy <= 1; dy++) {
      if (this.world.get(x + dx, Math.floor(this.position.y) + dy, z + dz) === 'campfire' && Math.hypot(dx, dz) <= 3) return true
    }
    return false
  }

  private updateCreature(dt: number): void {
    if (!this.enemy) return
    const night = this.timeOfDay > 0.78 || this.timeOfDay < 0.2
    const dx = this.position.x - this.enemy.position.x
    const dz = this.position.z - this.enemy.position.z
    const distance = Math.hypot(dx, dz)
    let walking = false
    if (night && distance < 32 && distance > 1.35) {
      const speed = 1.05
      const nx = this.enemy.position.x + (dx / distance) * speed * dt
      const nz = this.enemy.position.z + (dz / distance) * speed * dt
      this.enemy.position.set(nx, this.world.surfaceAt(nx, nz), nz)
      this.enemy.rotation.y = Math.atan2(dx, dz)
      walking = true
    }
    this.enemy.position.y = this.world.surfaceAt(this.enemy.position.x, this.enemy.position.z) + (walking ? 0 : Math.sin(this.elapsed * 1.7) * 0.014)
    const lit = night && distance < 34
    if (this.enemyGlow) {
      this.enemyGlow.position.set(this.enemy.position.x, this.enemy.position.y + 1.25, this.enemy.position.z)
      this.enemyGlow.intensity = lit ? 1.45 : 0
    }
    for (const material of this.enemyGlowMaterials) material.emissiveIntensity = lit ? 0.34 : 0
    if (night && distance < 1.55 && this.enemyAttack <= 0) {
      this.enemyAttack = 2.1
      this.health = Math.max(0, this.health - 14)
      this.audio.play('hurt')
      this.toast('Bóng Rêu tấn công! Lùi về nơi có ánh lửa.')
    }
    if (this.enemyWalk) this.enemyWalk.timeScale = walking ? 1 : 0.08
    else if (this.enemy) this.enemy.rotation.z = walking ? Math.sin(this.elapsed * 8) * 0.035 : 0
  }

  private toast(message: string): void {
    this.toastValue = message
    this.toastTime = 2.7
    this.hooks.toast(message)
  }
}
