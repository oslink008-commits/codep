# TODO — Blockwild: Voxel Survival

## Yêu cầu cốt lõi
- [x] Giữ yêu cầu “JS Game 3D Voxel” và lựa chọn thể loại **survival**.
- [x] Ghi nhận yêu cầu gốc “viết Game JS y hệt Bloxd.io”; giao phẩm là game sinh tồn voxel nguyên bản lấy cảm hứng khái quát, không sao chép nhận diện, giao diện, nội dung hoặc tài sản của trò chơi được nêu.
- [x] Dùng tiếng Việt cho giao diện và hướng dẫn trong game; ghim locale `vi-VN`.
- [x] Tạo đảo voxel mở để khám phá, thu thập tài nguyên, giữ máu/đói/khát, phá/đặt khối, chế tạo và dựng nơi trú ẩn.
- [x] Thêm chu kỳ ngày/đêm cùng Warden hoạt hình làm mối đe dọa ban đêm.
- [x] Giữ phạm vi đơn người chơi; không thêm multiplayer, backend hoặc dịch vụ mạng.

## Điều khiển, giao diện và tài sản
- [x] Duy trì nền tảng browser/Three.js; hỗ trợ bàn phím/chuột desktop và joystick/nút cảm ứng trên điện thoại.
- [x] Tạo menu, HUD, chỉ số sinh tồn, hotbar, chế tác và pause theo bản sắc riêng.
- [x] Tạo/tích hợp model Warden có rig và clip đi bộ theo lựa chọn tạo model/rigging đã duyệt; giữ ảnh tham chiếu trong thư mục scratch bị ignore.
- [x] Đăng ký GLB, PNG favicon và OG cover vào manifest Storage v2; cover phục vụ chia sẻ, không phải gameplay asset.
- [x] Chuẩn bị metadata sharing (title, description, favicon, OG/Twitter image) và logo project HTTPS.
- [x] Viết README tiếng Việt về cách chạy, điều khiển và giới hạn lưu tiến độ.

## Bản một file theo yêu cầu tiếp theo
- [x] “Cách chạy game bằng 1 file html”: xuất `blockwild.html` tự chứa mã, giao diện, font, favicon, model GLB và giấy phép cần thiết.
- [x] Giữ riêng bản web/Preview; đường dẫn asset CDN không thay đổi và không được gọi từ HTML standalone.
- [x] README có cách mở trực tiếp và lệnh `pnpm html:single` để tạo lại artifact.
- [x] Smoke mở thật qua `file://`, tải được thế giới/Warden/font, xác nhận kéo chuột dự phòng và không có yêu cầu HTTP(S).

## Kiểm tra
- [x] `pnpm build` — TypeScript, Vite build và kiểm tra bundle/font budgets đạt.
- [x] `pnpm html:single` — tạo `blockwild.html` tự chứa (~6.67 MiB).
- [x] `pnpm test` — 81 test qua.
- [x] `pnpm smoke` — desktop/mobile survival, đặt/phá voxel, chế tác, Warden, pause và file HTML standalone.
- [x] Kiểm tra Preview desktop và breakpoint điện thoại.

## Sửa lỗi người chơi vừa báo
- [ ] Giữ nguyên phản hồi: “cái gì vậy sao k có thanh đói với máu với bàn tay vuông kia và sao ko có cây mà nói là rừng còn nữa không có lá với vật ký à sao nó chặt rồi cây vẫn bay kìa”.
- [ ] Khi đang chơi, thanh Máu và Đói phải hiện rõ, đủ tương phản/kích thước trên desktop và điện thoại; vẫn hiển thị thêm Khát và cập nhật theo chỉ số thật.
- [ ] Hiện bàn tay/cẳng tay hình khối ở góc nhìn thứ nhất trong lúc chơi, theo phong cách voxel và có phản hồi khi đào; không che tâm ngắm.
- [ ] Rừng phải có thân cây và tán lá voxel dễ thấy gần điểm xuất phát lẫn trong đảo; màu lá phải phân biệt rõ với đất/đêm.
- [ ] Chặt gốc cây làm thân và tán đổ xuống có chuyển động trọng lực, rồi được dọn/thu hoạch; không còn thân hoặc lá lơ lửng trên không.
- [ ] Tạo lại `blockwild.html` sau khi sửa và xác minh các sửa đổi qua `file://` lẫn Preview, không làm mất Tweak, điều khiển cảm ứng hay trạng thái sinh tồn.

## Phạm vi gameplay mở rộng theo phản hồi mới nhất
- [ ] “Di chuyển gần cái cây xong nó dịch chuyển lên đầu cây cao luôn”: khi đi ngang/gần cây, nhân vật không được teleport hoặc tự bật lên tán, chỉ nhảy/collision tự nhiên.
- [ ] “Cây nó không rớt lá”: khi đốn cây, lá và gỗ phải có phản hồi rơi/decay hoặc drop rõ, không lơ lửng; giảm mật độ cây để khu rừng thoáng, bỏ cụm cây cố định sẵn ở spawn và dùng seed ngẫu nhiên khác nhau cho mỗi thế giới.
- [ ] “Bấm E tương tác thì nó mở bàn chế tạo dù chưa có bàn chế tạo”: E chỉ tương tác với vật thể phù hợp, không tự mở craft.
- [ ] “Mở inventory đâu phải bấm tab để mở inventory kèm bàn chế tạo sơ khai chỉ chế tạo 4 ô như minercaft”: Tab mở inventory và chế tạo cơ bản 2×2 với bốn công thức; phải chế tạo/đặt bàn rồi đứng gần và tương tác để mở chế tạo nâng cao.
- [ ] “Thanh trạng thái phải giống như minercaft mỗi tim và mỗi thanh đói riêng chứ không viết hình tim với số”: HUD dùng biểu tượng tim và đói riêng từng ô, không hiện số cạnh tim/đói. Thêm thanh XP độc lập và cộng điểm khi phá block theo độ hiếm.
- [ ] “Thêm đuốc độ sáng giảm theo 16 block tối đa”: đuốc đặt trong thế giới chiếu sáng suy giảm dần tới tối đa 16 block.
- [ ] “Tối sáng di chuyển theo từng đợt ko làm như tối liền”: chu kỳ dài hơn, bình minh/hoàng hôn từ từ.
- [ ] “Tối sẽ có zombie” nhưng “spam từng cái nhiều quá thì dừng chứ không phải spam tràn”: zombie chỉ xuất hiện ban đêm với giới hạn số lượng/tần suất rõ ràng.
- [ ] “Có bed chưa? bed phải là bấm vào nó chuyển cam về đầu như ngủ xong có nút thoát đó ... hiển thị chữ nhỏn là esc to stop khi mặt trời lên bằng animation giống phát nhanh thế giới ... chuyển cam về nhìn phía mặt trời ... bấm esc để dừng tại chỗ như đang đoạn ngủ 12h thì từ từ đến 3h thì esc là nó vào lúc 3h luôn”: chế tạo/đặt/tương tác với giường; hoạt cảnh hướng camera về mặt trời và tăng tốc thời gian; overlay nhỏ “Esc để dừng”; Esc dừng ở đúng giờ hiện tại, tự tỉnh lúc sáng, camera trở về tầm mắt.
- [ ] Giữ phạm vi chơi đơn, không bật online/multiplayer/backend; giữ tài sản và giao diện nguyên bản, Web Preview, HTML standalone, Three.js/Tweak và điều khiển cảm ứng hoạt động.
