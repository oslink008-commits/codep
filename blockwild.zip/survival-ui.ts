export type SurvivalAction = 'jump' | 'mine' | 'place' | 'interact'
export type InventorySlot = { type: string; name: string; count: number }
export type SurvivalHudData = {
  health: number
  hunger: number
  thirst: number
  day: number
  clock: string
  inventory: InventorySlot[]
  selected: number
  toast: string
  targetName: string
}
export type SurvivalUiCallbacks = {
  start: () => void
  pause: () => void
  resume: () => void
  retry: () => void
  home: () => void
  openCraft: () => void
  closeCraft: () => void
  craft: (recipe: string) => void
  select: (slot: number) => void
  touch: (action: SurvivalAction, down: boolean) => void
}

type Screen = 'boot' | 'title' | 'playing' | 'paused'
const recipes = [
  { id: 'planks', name: 'Ván gỗ', detail: '4 ván · Từ khúc gỗ', icon: '▤' },
  { id: 'crafting_table', name: 'Bàn chế tác', detail: 'Dựng nơi chế tạo', icon: '▦' },
  { id: 'campfire', name: 'Lửa trại', detail: 'Sưởi ấm trong đêm', icon: '♨' },
  { id: 'torch', name: 'Đuốc', detail: 'Soi sáng lối đi', icon: '✦' },
]
const blockFor = (type: string): string => {
  const key = type.toLowerCase()
  if (/wood|log|gỗ/.test(key)) return 'wood'
  if (/stone|rock|đá/.test(key)) return 'stone'
  if (/leaf|leaves|lá/.test(key)) return 'leaf'
  if (/food|berry|apple|thức ăn/.test(key)) return 'food'
  if (/torch|đuốc/.test(key)) return 'torch'
  if (/dirt|soil|đất/.test(key)) return 'earth'
  return 'wild'
}

export class SurvivalUI {
  private root: HTMLElement
  private callbacks: SurvivalUiCallbacks
  private toastTimer = 0

  constructor(root: HTMLElement, callbacks: SurvivalUiCallbacks) {
    this.root = root
    this.callbacks = callbacks
    this.root.classList.add('survival-root')
    this.root.innerHTML = `
      <section class="survival-screen survival-title is-active" data-screen="title" aria-label="Màn hình chính">
        <div class="survival-title-art" aria-hidden="true"><i class="survival-moon"></i><i class="survival-cloud cloud-one"></i><i class="survival-cloud cloud-two"></i><i class="survival-hill hill-back"></i><i class="survival-hill hill-front"></i><i class="survival-tree tree-one"><b></b></i><i class="survival-tree tree-two"><b></b></i><i class="survival-tree tree-three"><b></b></i><i class="survival-ground"></i></div>
        <div class="survival-title-content">
          <div class="survival-eyebrow"><span class="survival-dot"></span> NHẬT KÝ NGƯỜI ĐI RỪNG <span class="survival-eyebrow-line"></span></div>
          <h1>BLOCK<span>WILD</span></h1>
          <p class="survival-tagline">Sống sót qua từng khối</p>
          <p class="survival-intro">Một khu rừng mới đang chờ bạn. Gom nhặt tài nguyên, nhóm lửa trước hoàng hôn và tự dựng nên nơi trú ẩn của riêng mình.</p>
          <button class="survival-button survival-button-primary" data-action="start"><span>Vào rừng</span><b aria-hidden="true">↗</b></button>
          <div class="survival-title-note survival-title-note-desktop"><span class="survival-keycap">W A S D</span> di chuyển <span class="survival-note-divider">·</span> <span class="survival-keycap">E</span> tương tác</div>
          <div class="survival-title-note survival-title-note-touch">Dùng cần bên trái · Kéo phía phải để nhìn</div>
        </div>
        <div class="survival-title-caption"><span>01 / VÙNG ĐẤT HOANG</span><span>HÃY ĐỂ RỪNG DẪN LỐI</span></div>
      </section>
      <section class="survival-screen survival-boot" data-screen="boot" aria-label="Đang chuẩn bị Blockwild" aria-hidden="true"><img class="survival-boot-icon" src="./favicon.svg" alt="Biểu tượng Blockwild"><b class="survival-boot-title">BLOCKWILD</b><p>Đang chuẩn bị khu rừng</p><div class="survival-progress"><i></i></div><span class="survival-boot-number">0%</span><p class="survival-boot-error" data-boot-error hidden></p><button class="survival-boot-retry" data-action="retry" hidden>Thử tải lại</button></section>
      <section class="survival-screen survival-game" data-screen="playing" aria-label="Giao diện sinh tồn" aria-hidden="true">
        <div class="survival-vignette" aria-hidden="true"></div>
        <div class="survival-status survival-panel" role="group" aria-label="Chỉ số sinh tồn">
          <div class="survival-status-head"><span class="survival-status-mark" aria-hidden="true">✳</span><span>TRẠNG THÁI</span><span class="survival-live-dot" aria-hidden="true"></span></div>
          <div class="survival-meter-row meter-health"><span class="survival-meter-icon meter-heart" aria-hidden="true">♥</span><span class="survival-meter-label">Máu</span><div class="survival-meter" role="meter" aria-label="Máu" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100"><i data-meter="health"></i></div><b data-value="health">100</b></div>
          <div class="survival-meter-row meter-hunger"><span class="survival-meter-icon meter-hunger" aria-hidden="true">◆</span><span class="survival-meter-label">Đói</span><div class="survival-meter" role="meter" aria-label="Đói" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100"><i data-meter="hunger"></i></div><b data-value="hunger">100</b></div>
          <div class="survival-meter-row meter-thirst"><span class="survival-meter-icon meter-thirst" aria-hidden="true">●</span><span class="survival-meter-label">Khát</span><div class="survival-meter" role="meter" aria-label="Khát" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100"><i data-meter="thirst"></i></div><b data-value="thirst">100</b></div>
        </div>
        <div class="survival-top-right"><div class="survival-day survival-panel"><span class="survival-sun" aria-hidden="true">◒</span><span><small>NGÀY</small><b data-value="day">01</b></span><i></i><span class="survival-clock" data-value="clock">08:00</span></div><button class="survival-icon-button survival-panel" data-action="pause" aria-label="Tạm dừng" title="Tạm dừng (Esc)"><span aria-hidden="true">Ⅱ</span></button></div>
        <div class="survival-center" aria-hidden="true"><span class="survival-reticle"></span><span class="survival-target" data-value="targetName"></span></div>
        <div class="survival-hint survival-panel"><span class="survival-hint-key">E</span><span>Nhấn để tương tác</span></div>
        <button class="survival-craft-open survival-panel" data-action="craft-open" aria-label="Mở chế tác"><span aria-hidden="true">⌘</span> Chế tác <kbd>E</kbd></button>
        <div class="survival-controls-hint"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> Đi</span><span><kbd>F</kbd> / <kbd>Chuột trái</kbd> Đào</span><span><kbd>R</kbd> / <kbd>Chuột phải</kbd> Đặt</span><span><kbd>Space</kbd> Nhảy</span></div>
        <div class="survival-hotbar-wrap"><div class="survival-hotbar-label"><span>TÚI ĐỒ</span><span>Chọn ô <kbd>1–9</kbd></span></div><div class="survival-hotbar" data-hotbar></div></div>
        <div class="survival-touch" aria-label="Điều khiển cảm ứng"><div class="touch-stick" aria-hidden="true"><i></i></div><div class="survival-touch-actions"><button data-touch="interact" aria-label="Tương tác">E</button><button data-touch="place" aria-label="Đặt khối">▧</button><button data-touch="mine" aria-label="Đào khối">⛏</button><button data-touch="jump" aria-label="Nhảy">↑</button></div></div>
        <div class="survival-toast" role="status" aria-live="polite"></div>
        <aside class="survival-craft-drawer" aria-label="Bàn chế tác" aria-hidden="true"><div class="survival-drawer-head"><div><span class="survival-drawer-kicker">BÀN CHẾ TÁC</span><h2>Dựng nên điều gì?</h2></div><button class="survival-icon-button survival-drawer-close" data-action="craft-close" aria-label="Đóng chế tác">×</button></div><p class="survival-drawer-copy">Biến những gì bạn tìm thấy thành công cụ cho chuyến đi.</p><div class="survival-recipes">${recipes.map(r => `<button class="survival-recipe" data-recipe="${r.id}"><span class="survival-recipe-icon" aria-hidden="true">${r.icon}</span><span class="survival-recipe-text"><b>${r.name}</b><small>${r.detail}</small></span><span class="survival-recipe-arrow" aria-hidden="true">↗</span></button>`).join('')}</div><div class="survival-drawer-foot">CÔNG THỨC CƠ BẢN <span>04</span></div></aside>
      </section>
      <section class="survival-screen survival-pause" data-screen="paused" aria-label="Trò chơi tạm dừng" aria-hidden="true"><div class="survival-pause-card"><span class="survival-drawer-kicker">NGHỈ CHÂN MỘT CHÚT</span><h2>Rừng vẫn ở đây.</h2><p>Hít một hơi thật sâu. Chuyến đi còn dài.</p><button class="survival-button survival-button-primary" data-action="resume"><span>Tiếp tục hành trình</span><b aria-hidden="true">↗</b></button><button class="survival-button survival-button-quiet" data-action="home"><span>Trở về khu rừng</span></button><div class="survival-pause-footer"><kbd>Esc</kbd> để tiếp tục <span>·</span> Tiến độ được giữ nguyên</div></div></section>`

    this.root.addEventListener('click', this.onClick)
    this.root.addEventListener('pointerdown', this.onPointerDown)
    this.root.addEventListener('pointerup', this.onPointerUp)
    this.root.addEventListener('pointercancel', this.onPointerUp)
    this.root.addEventListener('lostpointercapture', this.onPointerUp)
    this.setScreen('title')
  }

  private onClick = (event: Event): void => {
    const target = event.target
    if (!(target instanceof Element)) return
    const button = target.closest<HTMLElement>('[data-action], [data-recipe], [data-slot]')
    if (!button || !this.root.contains(button)) return
    const action = button.dataset.action
    if (button.dataset.recipe) this.callbacks.craft(button.dataset.recipe)
    else if (button.dataset.slot !== undefined) this.callbacks.select(Number(button.dataset.slot))
    else if (action === 'start') this.callbacks.start()
    else if (action === 'resume') this.callbacks.resume()
    else if (action === 'retry') this.callbacks.retry()
    else if (action === 'home') this.callbacks.home()
    else if (action === 'pause') this.callbacks.pause()
    else if (action === 'craft-open') { this.callbacks.openCraft(); this.setCraftOpen(true) }
    else if (action === 'craft-close') { this.callbacks.closeCraft(); this.setCraftOpen(false) }
  }

  private onPointerDown = (event: PointerEvent): void => {
    const target = event.target
    if (!(target instanceof Element)) return
    const button = target.closest<HTMLElement>('[data-touch]')
    if (!button || !this.root.contains(button)) return
    event.preventDefault()
    event.stopPropagation()
    const action = button.dataset.touch as SurvivalAction
    if (['jump', 'mine', 'place', 'interact'].includes(action)) {
      button.classList.add('is-pressed')
      try { button.setPointerCapture(event.pointerId) } catch { /* pointer may already be released */ }
      this.callbacks.touch(action, true)
    }
  }

  private onPointerUp = (event: Event): void => {
    const target = event.target
    if (!(target instanceof Element)) return
    const button = target.closest<HTMLElement>('[data-touch]')
    if (!button) return
    button.classList.remove('is-pressed')
    const action = button.dataset.touch as SurvivalAction
    if (['jump', 'mine', 'place', 'interact'].includes(action)) this.callbacks.touch(action, false)
  }

  private setCraftOpen(open: boolean): void {
    const drawer = this.root.querySelector<HTMLElement>('.survival-craft-drawer')
    if (!drawer) return
    drawer.classList.toggle('is-open', open)
    drawer.setAttribute('aria-hidden', String(!open))
  }

  openCraft(): void { this.setCraftOpen(true) }
  closeCraft(): void { this.setCraftOpen(false) }
  isCraftOpen(): boolean { return this.root.querySelector('.survival-craft-drawer')?.classList.contains('is-open') ?? false }

  setScreen(screen: Screen): void {
    this.root.dataset.survivalScreen = screen
    this.root.querySelectorAll<HTMLElement>('.survival-screen').forEach(el => {
      const active = el.dataset.screen === screen
      el.classList.toggle('is-active', active)
      el.setAttribute('aria-hidden', String(!active))
      el.inert = !active
    })
    if (screen !== 'playing') this.setCraftOpen(false)
  }

  setBootProgress(progress: number): void {
    const value = Math.max(0, Math.min(100, Number.isFinite(progress) ? progress : 0))
    const bar = this.root.querySelector<HTMLElement>('.survival-progress i')
    const label = this.root.querySelector<HTMLElement>('.survival-boot-number')
    if (bar) bar.style.transform = `scaleX(${value / 100})`
    if (label) label.textContent = `${Math.round(value)}%`
  }

  setBootError(message: string): void {
    const error = this.root.querySelector<HTMLElement>('[data-boot-error]')
    const retry = this.root.querySelector<HTMLButtonElement>('.survival-boot-retry')
    if (error) { error.textContent = message; error.hidden = !message }
    if (retry) retry.hidden = !message
  }

  update(data: SurvivalHudData): void {
    const setValue = (key: string, value: string): void => {
      const el = this.root.querySelector<HTMLElement>(`[data-value="${key}"]`)
      if (el) el.textContent = value
    }
    for (const key of ['health', 'hunger', 'thirst'] as const) {
      const value = Math.max(0, Math.min(100, Number(data[key]) || 0))
      const meter = this.root.querySelector<HTMLElement>(`[data-meter="${key}"]`)
      if (meter) {
        meter.style.width = `${value}%`
        meter.parentElement?.setAttribute('aria-valuenow', String(Math.round(value)))
      }
      setValue(key, String(Math.round(value)))
    }
    setValue('day', String(Math.max(1, Math.floor(data.day || 1))).padStart(2, '0'))
    setValue('clock', data.clock ?? '')
    setValue('targetName', data.targetName ?? '')
    const target = this.root.querySelector<HTMLElement>('.survival-hint')
    if (target) target.classList.toggle('is-visible', Boolean(data.targetName))
    const hotbar = this.root.querySelector<HTMLElement>('[data-hotbar]')
    if (hotbar) {
      hotbar.replaceChildren()
      for (let i = 0; i < 9; i++) {
        const item = data.inventory?.[i]
        const slot = document.createElement('button')
        slot.type = 'button'
        slot.className = `survival-slot${i === data.selected ? ' is-selected' : ''}${item ? '' : ' is-empty'}`
        slot.dataset.slot = String(i)
        slot.setAttribute('aria-label', item ? `Ô ${i + 1}: ${item.name}, ${item.count}` : `Ô ${i + 1}: trống`)
        slot.setAttribute('aria-pressed', String(i === data.selected))
        const number = document.createElement('span')
        number.className = 'survival-slot-number'
        number.textContent = String(i + 1)
        slot.append(number)
        if (item) {
          const icon = document.createElement('span')
          icon.className = `survival-block survival-block-${blockFor(item.type)}`
          icon.setAttribute('aria-hidden', 'true')
          const glyph = document.createElement('i')
          glyph.textContent = blockFor(item.type) === 'food' ? '✦' : blockFor(item.type) === 'torch' ? '│' : ''
          icon.append(glyph)
          slot.append(icon)
          const count = document.createElement('span')
          count.className = 'survival-slot-count'
          count.textContent = String(item.count)
          slot.append(count)
          const name = document.createElement('span')
          name.className = 'survival-slot-name'
          name.textContent = item.name
          slot.append(name)
        }
        hotbar.append(slot)
      }
    }
    if (data.toast) this.toast(data.toast)
  }

  toast(message: string): void {
    const el = this.root.querySelector<HTMLElement>('.survival-toast')
    if (!el) return
    el.textContent = message
    el.classList.add('is-visible')
    window.clearTimeout(this.toastTimer)
    this.toastTimer = window.setTimeout(() => el.classList.remove('is-visible'), 2600)
  }
}
