import { build } from 'vite'
import { readdir, readFile, rm, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, join, resolve, sep } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const outputPath = join(root, 'blockwild.html')
const tempDir = await fsMkdtemp('blockwild-single-')

async function fsMkdtemp(prefix) {
  const { mkdtemp } = await import('node:fs/promises')
  return mkdtemp(join(tmpdir(), prefix))
}

function oneMatch(items, label) {
  if (items.length !== 1) throw new Error(`Expected one ${label} for standalone export; got ${items.length}.`)
  return items[0]
}

function assetPath(temp, url) {
  const relative = decodeURIComponent(url).replace(/^\.\//, '').replace(/^\//, '')
  const target = resolve(temp, relative)
  if (!target.startsWith(`${temp}${sep}`)) throw new Error(`Unsafe generated asset path: ${url}`)
  return target
}

function escapeHtml(text) {
  return text.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
}

async function main() {
  await build({
    configFile: false,
    root,
    mode: 'production',
    base: './',
    publicDir: join(root, 'public'),
    build: {
      outDir: tempDir,
      emptyOutDir: true,
      copyPublicDir: true,
      assetsInlineLimit: 0,
      cssCodeSplit: false,
      minify: true,
      sourcemap: false,
      target: 'es2022',
      reportCompressedSize: false,
      chunkSizeWarningLimit: 1200,
      rollupOptions: {
        input: join(root, 'index.html'),
        output: {
          codeSplitting: false,
          format: 'es',
          entryFileNames: 'assets/game.js',
          chunkFileNames: 'assets/chunk-[name].js',
          assetFileNames: 'assets/[name]-[hash][extname]',
        },
      },
    },
  })

  let html = await readFile(join(tempDir, 'index.html'), 'utf8')
  const scriptTag = oneMatch([...html.matchAll(/<script\b(?=[^>]*\bsrc=)[^>]*>\s*<\/script>/gi)], 'bundled script tag')[0]
  const scriptUrl = scriptTag.match(/\bsrc=["']([^"']+)["']/i)?.[1]
  if (!scriptUrl) throw new Error('The generated game script has no URL.')
  const cssTag = oneMatch([...html.matchAll(/<link\b[^>]*>/gi)].filter(([tag]) => /\brel=["']stylesheet["']/i.test(tag)), 'bundled stylesheet tag')[0]
  const cssUrl = cssTag.match(/\bhref=["']([^"']+)["']/i)?.[1]
  if (!cssUrl) throw new Error('The generated game stylesheet has no URL.')
  let javascript = await readFile(assetPath(tempDir, scriptUrl), 'utf8')
  let css = await readFile(assetPath(tempDir, cssUrl), 'utf8')

  // Convert every shipped font URL to a data URL; never rely on public/fonts at runtime.
  const fontDirectory = join(root, 'public', 'fonts')
  const fontFiles = (await readdir(fontDirectory)).filter(name => /\.(ttf|woff2)$/i.test(name))
  const fonts = new Map()
  for (const name of fontFiles) {
    const bytes = await readFile(join(fontDirectory, name))
    const mime = name.toLowerCase().endsWith('.woff2') ? 'font/woff2' : 'font/ttf'
    fonts.set(name, `data:${mime};base64,${bytes.toString('base64')}`)
  }
  const embeddedFonts = new Set()
  css = css.replace(/url\(([^)]+)\)/gi, (match, rawValue) => {
    const value = rawValue.trim().replace(/^["']|["']$/g, '')
    if (/^(?:data:|blob:|#)/i.test(value)) return match
    const name = basename(new URL(value, 'https://blockwild.invalid').pathname)
    const data = fonts.get(name)
    if (data) {
      embeddedFonts.add(name)
      return `url("${data}")`
    }
    if (/^(?:https?:|\/\/|\/|\.\/|\.\.\/|file:)/i.test(value)) {
      throw new Error(`Unembedded external or local CSS dependency: ${value}`)
    }
    return match
  })
  if (!fontFiles.length || embeddedFonts.size !== fontFiles.length) {
    throw new Error(`Font embedding incomplete: ${embeddedFonts.size}/${fontFiles.length} font files referenced.`)
  }

  // The GLB must be self-contained itself; then its bytes can travel inside this one HTML.
  const modelPath = join(root, 'assets', 'models', 'moss-warden.glb')
  const model = await readFile(modelPath)
  if (model.toString('ascii', 0, 4) !== 'glTF') throw new Error('Warden asset is not a binary glTF file.')
  const jsonLength = model.readUInt32LE(12)
  const gltf = JSON.parse(model.subarray(20, 20 + jsonLength).toString('utf8').trim())
  const external = [...(gltf.buffers ?? []), ...(gltf.images ?? [])]
    .map(resource => resource.uri)
    .filter(uri => typeof uri === 'string' && !uri.startsWith('data:'))
  if (external.length) throw new Error(`Warden GLB has external dependencies: ${external.join(', ')}`)
  const svg = await readFile(join(root, 'public', 'favicon.svg'))
  const embedded = {
    mossWarden: `data:model/gltf-binary;base64,${model.toString('base64')}`,
    favicon: `data:image/svg+xml;base64,${svg.toString('base64')}`,
  }

  // Inline the single generated JS/CSS entry, favicon, and fonts for direct file:// execution.
  html = html.replace(/<link\b(?=[^>]*\brel=["']modulepreload["'])[^>]*>\s*/gi, '')
  html = html.replace(/<link\b(?=[^>]*\brel=["']preload["'])[^>]*>\s*/gi, '')
  html = html.replace(cssTag, () => `<style>\n${css.replace(/<\/style/gi, '<\\/style')}\n</style>`)
  html = html.replace(/<link\b(?=[^>]*\brel=["']icon["'])[^>]*>/i, () =>
    `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${svg.toString('base64')}">`)
  const bootstrap = `<script>window.__BLOCKWILD_EMBEDDED_ASSETS__=${JSON.stringify(embedded)};</script>`
  const inlineModule = `<script type="module">\n${javascript.replace(/<\/script/gi, '<\\/script')}\n</script>`
  html = html.replace(scriptTag, () => `${bootstrap}\n${inlineModule}`)

  const licensePaths = [
    { path: join(root, 'public', 'fonts', 'ManusCC0-LICENSE.txt'), label: 'ManusCC0 fonts — CC0 1.0' },
    { path: join(root, 'node_modules', 'three', 'LICENSE'), label: 'Three.js — MIT License' },
  ]
  const notices = []
  for (const item of licensePaths) {
    const content = await readFile(item.path, 'utf8')
    notices.push(`${item.label}\n${content}`)
  }
  const licenses = `<template id="blockwild-third-party-licenses"><pre>${escapeHtml(notices.join('\n\n'))}</pre></template>`
  html = html.replace('</body>', () => `${licenses}\n</body>`)

  if (/<script\b[^>]*\bsrc=/i.test(html)) throw new Error('Standalone HTML still references a separate JavaScript file.')
  if (/<link\b[^>]*\brel=["']stylesheet["']/i.test(html)) throw new Error('Standalone HTML still references a separate CSS file.')
  const unresolved = [...html.matchAll(/<(?:script|link)\b[^>]*>/gi)]
    .map(([tag]) => tag.match(/\b(?:src|href)=["']([^"']+)["']/i)?.[1])
    .filter(url => typeof url === 'string' && !/^(?:data:|#|javascript:)/i.test(url))
  if (unresolved.length) throw new Error(`Standalone HTML has external/file dependencies: ${unresolved.join(', ')}`)

  await writeFile(outputPath, `<!-- Self-contained offline export. Regenerate with pnpm html:single. -->\n${html}`)
  const size = (await stat(outputPath)).size
  console.log(`standalone: ${outputPath} (${(size / 1024 / 1024).toFixed(2)} MiB); JS/CSS/fonts/favicon/Warden are embedded.`)
}

try {
  await main()
} finally {
  await rm(tempDir, { recursive: true, force: true })
}
