/**
 * Unified input: keyboard + mouse (pointer lock), gamepad and touch all feed one action state.
 * Gameplay reads `move`, `look` and `pressed()/held()`; it never checks raw keys.
 *
 * Call `endFrame()` once per rendered frame after gameplay consumed edge-triggered presses.
 */
export type Action = 'jump' | 'sprint' | 'dash' | 'pause' | 'confirm' | 'back' | 'interact' | 'mine' | 'place' | 'inventory'
export type InputMethod = 'keyboard' | 'gamepad' | 'touch'

const KEY_BINDINGS: Record<Action, string[]> = {
  jump: ['Space'],
  sprint: ['ShiftLeft', 'ShiftRight'],
  dash: [],
  pause: ['Escape', 'KeyP'],
  confirm: ['Enter', 'NumpadEnter'],
  // Menus handle Escape/Backspace themselves via DOM keydown; `back` is the gamepad B button.
  back: [],
  interact: ['KeyE'],
  mine: ['KeyF'],
  place: ['KeyR'],
  inventory: ['Tab'],
}
const MOVE_KEYS = { up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'] }
// Standard gamepad mapping: A=0, B=1, X=2, Y=3, LB=4, RB=5, RT=7, Start=9, L3=10.
const PAD_BINDINGS: Record<Action, number[]> = { jump: [0], sprint: [4, 10], dash: [2, 5, 7], pause: [9], confirm: [0], back: [1], interact: [3], mine: [7], place: [5], inventory: [] }

export class Input {
  /** Movement intent in [-1, 1]: x = strafe right, y = forward. */
  readonly move = { x: 0, y: 0 }
  /** Camera look delta accumulated since the last `endFrame()` (radians-ish units, pre-sensitivity). */
  readonly look = { x: 0, y: 0 }
  method: InputMethod = 'keyboard'
  /** Multiplies look deltas; settings screen writes it. */
  sensitivity = 1
  invertY = false

  private keys = new Set<string>()
  private held_ = new Set<Action>()
  private pressed_ = new Set<Action>()
  private touchMove = { x: 0, y: 0 }
  private touchButtons = new Set<Action>()
  private mouseButtons = new Set<number>()
  private padPrev: boolean[] = []
  private padIndex = -1
  private padId = ''
  private listeners: Array<() => void> = []

  constructor(private readonly canvas: HTMLCanvasElement) {
    const on = <K extends keyof WindowEventMap>(target: Window | HTMLElement, type: K, fn: (e: WindowEventMap[K]) => void, opts?: AddEventListenerOptions) => {
      target.addEventListener(type, fn as EventListener, opts)
      this.listeners.push(() => target.removeEventListener(type, fn as EventListener))
    }
    const standaloneFile = typeof location !== 'undefined' && location.protocol === 'file:'
    if (standaloneFile) {
      let dragPointer = -1
      let lastX = 0
      let lastY = 0
      on(canvas, 'pointerdown', e => {
        if (e.pointerType !== 'mouse' || document.pointerLockElement === canvas) return
        dragPointer = e.pointerId
        lastX = e.clientX
        lastY = e.clientY
        try { canvas.setPointerCapture(e.pointerId) } catch { /* the browser may deny capture */ }
      })
      on(canvas, 'pointermove', e => {
        if (e.pointerId !== dragPointer || document.pointerLockElement === canvas) return
        this.look.x += (e.clientX - lastX) * 0.0022
        this.look.y += (e.clientY - lastY) * 0.0022
        lastX = e.clientX
        lastY = e.clientY
      })
      const finishDrag = (e: PointerEvent) => { if (e.pointerId === dragPointer) dragPointer = -1 }
      on(canvas, 'pointerup', finishDrag)
      on(canvas, 'pointercancel', finishDrag)
    }
    on(window, 'keydown', e => {
      if (e.repeat) return
      this.keys.add(e.code)
      this.method = 'keyboard'
      for (const [action, codes] of Object.entries(KEY_BINDINGS) as [Action, string[]][]) {
        if (codes.includes(e.code)) this.pressed_.add(action)
      }
      // Keep the page from scrolling, but never block typing in text fields (leaderboard name).
      const typing = (e.target as HTMLElement | null)?.matches?.('input, textarea')
      if (!typing && (e.code === 'Space' || e.code.startsWith('Arrow') || e.code === 'Tab')) e.preventDefault()
    })
    on(window, 'keyup', e => this.keys.delete(e.code))
    on(window, 'blur', () => { this.keys.clear(); this.mouseButtons.clear() })
    on(window, 'gamepaddisconnected', e => {
      if (e.gamepad.index === this.padIndex) this.resetPad()
    })
    on(window, 'mousedown', e => {
      if (document.pointerLockElement !== canvas) return
      if (e.button === 0) this.pressed_.add('mine')
      if (e.button === 2) this.pressed_.add('place')
      this.mouseButtons.add(e.button)
    })
    on(window, 'mouseup', e => this.mouseButtons.delete(e.button))
    on(window, 'contextmenu', e => { if (document.pointerLockElement === canvas) e.preventDefault() })
    on(window, 'mousemove', e => {
      if (document.pointerLockElement !== canvas) return
      this.look.x += e.movementX * 0.0022
      this.look.y += e.movementY * 0.0022
    })
  }

  /** Request pointer lock for mouse look (must be called from a user gesture). */
  lockPointer(): void {
    if (this.method !== 'touch' && document.pointerLockElement !== this.canvas) {
      this.canvas.requestPointerLock?.()?.catch?.(() => undefined)
    }
  }

  unlockPointer(): void {
    if (document.pointerLockElement) document.exitPointerLock()
  }

  /** Touch controls feed these from the on-screen joystick and buttons. */
  setTouchMove(x: number, y: number): void {
    this.method = 'touch'
    this.touchMove.x = x
    this.touchMove.y = y
  }

  addTouchLook(dx: number, dy: number): void {
    this.method = 'touch'
    this.look.x += dx * 0.006
    this.look.y += dy * 0.006
  }

  setTouchButton(action: Action, down: boolean): void {
    this.method = 'touch'
    if (down && !this.touchButtons.has(action)) this.pressed_.add(action)
    if (down) this.touchButtons.add(action)
    else this.touchButtons.delete(action)
  }

  private resetPad(): void {
    this.padPrev = []
    this.padIndex = -1
    this.padId = ''
  }

  /** Sample once per rendered frame; elapsed time scales continuous stick look only. */
  update(frameSeconds = 1 / 60): void {
    const k = (codes: string[]) => codes.some(code => this.keys.has(code))
    let x = (k(MOVE_KEYS.right) ? 1 : 0) - (k(MOVE_KEYS.left) ? 1 : 0)
    let y = (k(MOVE_KEYS.up) ? 1 : 0) - (k(MOVE_KEYS.down) ? 1 : 0)
    this.held_.clear()
    for (const [action, codes] of Object.entries(KEY_BINDINGS) as [Action, string[]][]) {
      if (k(codes)) this.held_.add(action)
    }
    for (const action of this.touchButtons) this.held_.add(action)
    if (this.mouseButtons.has(0)) this.held_.add('mine')
    if (this.mouseButtons.has(2)) this.held_.add('place')
    if (this.touchMove.x !== 0 || this.touchMove.y !== 0) {
      x = this.touchMove.x
      y = this.touchMove.y
    }
    const pad = navigator.getGamepads?.().find(p => p && p.connected)
    if (pad) {
      if (pad.index !== this.padIndex || pad.id !== this.padId) this.padPrev = []
      this.padIndex = pad.index
      this.padId = pad.id
      const dead = (v: number) => (Math.abs(v) < 0.18 ? 0 : v)
      const lx = dead(pad.axes[0] ?? 0)
      const ly = dead(pad.axes[1] ?? 0)
      const rx = dead(pad.axes[2] ?? 0)
      const ry = dead(pad.axes[3] ?? 0)
      const padActive = lx !== 0 || ly !== 0 || rx !== 0 || ry !== 0 || pad.buttons.some(b => b.pressed)
      if (padActive) this.method = 'gamepad'
      const dx = (pad.buttons[15]?.pressed ? 1 : 0) - (pad.buttons[14]?.pressed ? 1 : 0)
      const dy = (pad.buttons[12]?.pressed ? 1 : 0) - (pad.buttons[13]?.pressed ? 1 : 0)
      if (lx !== 0 || ly !== 0 || dx !== 0 || dy !== 0) {
        x = dx || lx
        y = dy || -ly
      }
      // Preserve the 60 Hz turn rate at every render frequency.
      this.look.x += rx * 2.7 * frameSeconds
      this.look.y += ry * 2.7 * frameSeconds
      for (const [action, buttons] of Object.entries(PAD_BINDINGS) as [Action, number[]][]) {
        if (buttons.some(i => pad.buttons[i]?.pressed)) this.held_.add(action)
        // Alternate bindings are independent physical presses, even when another is held.
        if (buttons.some(i => pad.buttons[i]?.pressed && !this.padPrev[i])) this.pressed_.add(action)
      }
      this.padPrev = pad.buttons.map(b => b.pressed)
    } else this.resetPad()
    const len = Math.hypot(x, y)
    this.move.x = len > 1 ? x / len : x
    this.move.y = len > 1 ? y / len : y
  }

  held(action: Action): boolean {
    return this.held_.has(action)
  }

  /** True once per physical press. */
  pressed(action: Action): boolean {
    return this.pressed_.has(action)
  }

  /**
   * Read and clear a press. Use this inside fixed simulation steps: several steps can run in one
   * rendered frame, and a press must trigger exactly one jump/confirm.
   */
  consume(action: Action): boolean {
    return this.pressed_.delete(action)
  }

  /** Consume the look delta with sensitivity/invert applied. */
  takeLook(): { x: number; y: number } {
    const out = { x: this.look.x * this.sensitivity, y: this.look.y * this.sensitivity * (this.invertY ? -1 : 1) }
    this.look.x = 0
    this.look.y = 0
    return out
  }

  endFrame(): void {
    this.pressed_.clear()
  }

  dispose(): void {
    for (const off of this.listeners) off()
    this.listeners = []
  }
}
