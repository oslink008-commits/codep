import * as THREE from 'three'

export type BlockType = 'grass' | 'dirt' | 'stone' | 'log' | 'leaves' | 'sand' | 'wood' | 'coal' | 'iron' | 'planks' | 'crafting_table' | 'campfire' | 'torch' | 'water' | 'bedrock'
export type BlockHit = { x: number; y: number; z: number; type: BlockType; point: THREE.Vector3; normal: THREE.Vector3; distance: number }

const CHUNK = 16
const COLORS: Record<BlockType, THREE.Color> = {
  grass: new THREE.Color('#477f68'), dirt: new THREE.Color('#795743'), stone: new THREE.Color('#788783'),
  log: new THREE.Color('#80583c'), leaves: new THREE.Color('#53b84b'), sand: new THREE.Color('#c8ad72'),
  wood: new THREE.Color('#936344'), coal: new THREE.Color('#424846'), iron: new THREE.Color('#b08f79'),
  planks: new THREE.Color('#ad8050'), crafting_table: new THREE.Color('#c18843'), campfire: new THREE.Color('#e98b43'),
  torch: new THREE.Color('#e9b65b'), water: new THREE.Color('#397d83'), bedrock: new THREE.Color('#343e3e'),
}
const FACE_DATA: { n: [number, number, number]; corners: [number, number, number][]; shade: number }[] = [
  { n: [1, 0, 0], corners: [[1,0,0],[1,1,0],[1,1,1],[1,0,1]], shade: 0.78 },
  { n: [-1, 0, 0], corners: [[0,0,1],[0,1,1],[0,1,0],[0,0,0]], shade: 0.72 },
  { n: [0, 1, 0], corners: [[0,1,1],[1,1,1],[1,1,0],[0,1,0]], shade: 1 },
  { n: [0, -1, 0], corners: [[0,0,0],[1,0,0],[1,0,1],[0,0,1]], shade: 0.58 },
  { n: [0, 0, 1], corners: [[1,0,1],[1,1,1],[0,1,1],[0,0,1]], shade: 0.86 },
  { n: [0, 0, -1], corners: [[0,0,0],[0,1,0],[1,1,0],[1,0,0]], shade: 0.82 },
]
const FACE_OFFSETS: [number, number, number][] = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]
const leafTint = (x: number, y: number, z: number): number => {
  const hash = (Math.imul(x + 32768, 73856093) ^ Math.imul(y + 32768, 19349663) ^ Math.imul(z + 32768, 83492791)) >>> 0
  return 0.72 + (hash / 0xffffffff) * 0.44
}

/** Seeded, bounded voxel terrain rendered as one indexed-by-chunk mesh per 16x16 footprint. */
export class VoxelWorld {
  readonly scene: THREE.Scene
  readonly blocks = new Map<string, BlockType>()
  readonly meshGroup = new THREE.Group()
  readonly spawn = new THREE.Vector3(0.5, 0, 0.5)
  readonly collidableMeshes: THREE.Mesh[] = []
  private readonly material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0.02 })
  private readonly chunks = new Map<string, THREE.Mesh>()
  private readonly dirty = new Set<string>()
  private readonly water: THREE.Mesh
  private readonly skyLight: THREE.HemisphereLight
  private readonly sun: THREE.DirectionalLight
  private disposed = false
  private readonly fallingTrees: { group: THREE.Group; angularVelocity: number; age: number; angle: number; axis: THREE.Vector3 }[] = []
  private readonly fallGeometry = new THREE.BoxGeometry(1, 1, 1)
  private readonly fallMaterials = { log: new THREE.MeshStandardMaterial({ color: '#80583c', roughness: 0.9 }), leaves: new THREE.MeshStandardMaterial({ color: '#53b84b', roughness: 0.9 }) }

  constructor(scene?: THREE.Scene, seed = Math.floor(Math.random() * 0x100000000)) {
    this.scene = scene ?? new THREE.Scene()
    this.scene.background = new THREE.Color('#a7c3b2')
    this.scene.fog = new THREE.Fog('#a7c3b2', 42, 108)
    this.skyLight = new THREE.HemisphereLight('#d4e7da', '#52645b', 1.35)
    this.scene.add(this.skyLight)
    this.sun = new THREE.DirectionalLight('#ffe0a0', 2.1)
    this.sun.position.set(-32, 48, 26)
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(1024, 1024)
    this.sun.shadow.camera.left = this.sun.shadow.camera.bottom = -38
    this.sun.shadow.camera.right = this.sun.shadow.camera.top = 38
    this.scene.add(this.sun, this.sun.target)
    this.scene.add(this.meshGroup)

    let state = seed >>> 0
    const random = (): number => {
      state = (state + 0x6d2b79f5) >>> 0
      let t = state
      t = Math.imul(t ^ (t >>> 15), t | 1)
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296
    }
    const height = (x: number, z: number): number => {
      const d = Math.hypot(x, z)
      const edge = Math.max(0, 1 - Math.pow(d / 29, 2))
      const wave = Math.sin(x * 0.19 + seed * 0.001) * 1.05 + Math.cos(z * 0.16 - seed * 0.002) * 0.85 + Math.sin((x + z) * 0.11) * 0.65
      return d > 28 ? 0 : Math.max(3, Math.floor(4 + edge * 3 + wave))
    }
    for (let x = -28; x < 28; x++) for (let z = -28; z < 28; z++) {
      const h = height(x, z)
      if (!h) continue
      const shore = h <= 4
      for (let y = 0; y < h; y++) {
        let type: BlockType = y === 0 ? 'bedrock' : y === h - 1 ? (shore ? 'sand' : 'grass') : y >= h - 3 ? 'dirt' : 'stone'
        // Sparse shallow ore pockets, deliberately exposed on occasional cliff faces.
        if (y > 1 && y < h - 1 && random() < (type === 'stone' ? 0.018 : 0)) type = random() < 0.62 ? 'coal' : 'iron'
        this.blocks.set(this.key(x, y, z), type)
      }
    }
    // A level clearing for the starting position; its feet position is one unit above the top block.
    const sy = height(0, 0) - 1
    for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) {
      const top = height(x, z) - 1
      for (let y = sy + 1; y <= top; y++) this.blocks.delete(this.key(x, y, z))
      if (top !== sy) this.blocks.set(this.key(x, sy, z), 'grass')
    }
    this.spawn.set(0.5, sy + 1, 0.5)

    // Keep a wide clearing around spawn; place a distinct ring of starter trees beyond it.
    for (let x = -25; x <= 25; x++) for (let z = -25; z <= 25; z++) {
      if (Math.hypot(x, z) < 11 || Math.hypot(x, z) > 26 || random() > 0.075) continue
      this.plantTree(x, z, height, random)
    }
    // A sparse grove frames the view at spawn without surrounding the player in foliage.
    for (const [tx, tz] of [[-8, -5], [8, -5], [-8, 4], [8, 4], [0, 9], [-4, -9], [4, -9], [0, -10]] as const) this.plantTree(tx, tz, height, random)
    this.water = new THREE.Mesh(new THREE.PlaneGeometry(72, 72), new THREE.MeshStandardMaterial({ color: '#4d9a98', transparent: true, opacity: 0.36, roughness: 0.28, metalness: 0.08, side: THREE.DoubleSide, depthWrite: false }))
    this.water.rotation.x = -Math.PI / 2
    this.water.position.y = 3.15
    this.water.renderOrder = 1
    this.scene.add(this.water)

    for (const k of this.blocks.keys()) {
      const [x, , z] = this.parseKey(k)
      this.dirty.add(this.chunkKey(x, z))
    }
    this.flushDirty()
  }

  private plantTree(x: number, z: number, height: (x: number, z: number) => number, random: () => number): void {
    const top = height(x, z) - 1
    if (top < 4 || this.get(x, top, z) !== 'grass') return
    const trunkHeight = 3 + Math.floor(random() * 3)
    for (let y = top; y < top + trunkHeight; y++) this.blocks.set(this.key(x, y, z), 'log')
    const crownY = top + trunkHeight - 1
    for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = -1; dy <= 2; dy++) {
      const radius = dy === 0 ? 2 : dy === 1 ? 1 : dy === 2 ? 0 : 1
      if (Math.abs(dx) + Math.abs(dz) > radius + 1 || (dx === 0 && dz === 0 && dy < 1)) continue
      const bx = x + dx, by = crownY + dy, bz = z + dz
      if (!this.blocks.has(this.key(bx, by, bz))) this.blocks.set(this.key(bx, by, bz), 'leaves')
    }
  }
  private key(x: number, y: number, z: number): string { return `${x},${y},${z}` }
  private parseKey(key: string): [number, number, number] { return key.split(',').map(Number) as [number, number, number] }
  private chunkKey(x: number, z: number): string { return `${Math.floor(x / CHUNK)},${Math.floor(z / CHUNK)}` }
  get(x: number, y: number, z: number): BlockType | undefined { return this.blocks.get(this.key(x, y, z)) }

  /** Set a voxel to a type, or remove it with null; touching chunks rebuild on both sides of seams. */
  set(x: number, y: number, z: number, type: BlockType | null): boolean {
    if (![x, y, z].every(Number.isInteger)) return false
    const k = this.key(x, y, z), old = this.blocks.get(k)
    if (old === type || (!old && type === null)) return false
    if (type === null) this.blocks.delete(k); else this.blocks.set(k, type)
    this.dirty.add(this.chunkKey(x, z))
    if (x % CHUNK === 0 && this.get(x - 1, y, z)) this.dirty.add(this.chunkKey(x - 1, z))
    if ((x + 1) % CHUNK === 0 && this.get(x + 1, y, z)) this.dirty.add(this.chunkKey(x + 1, z))
    if (z % CHUNK === 0 && this.get(x, y, z - 1)) this.dirty.add(this.chunkKey(x, z - 1))
    if ((z + 1) % CHUNK === 0 && this.get(x, y, z + 1)) this.dirty.add(this.chunkKey(x, z + 1))
    this.flushDirty()
    return true
  }

  private flushDirty(): void {
    for (const ck of this.dirty) this.rebuildChunk(ck)
    this.dirty.clear()
  }

  /** Remove many voxels while rebuilding each affected chunk only once. */
  setBatch(changes: { x: number; y: number; z: number; type: BlockType | null }[]): number {
    let changed = 0
    for (const { x, y, z, type } of changes) {
      if (![x, y, z].every(Number.isInteger)) continue
      const key = this.key(x, y, z), old = this.blocks.get(key)
      if (old === type || (!old && type === null)) continue
      if (type === null) this.blocks.delete(key); else this.blocks.set(key, type)
      this.dirty.add(this.chunkKey(x, z)); changed++
      if (x % CHUNK === 0) this.dirty.add(this.chunkKey(x - 1, z))
      if ((x + 1) % CHUNK === 0) this.dirty.add(this.chunkKey(x + 1, z))
      if (z % CHUNK === 0) this.dirty.add(this.chunkKey(x, z - 1))
      if ((z + 1) % CHUNK === 0) this.dirty.add(this.chunkKey(x, z + 1))
    }
    this.flushDirty()
    return changed
  }
  /** Fell a connected log/leaf crown only when the selected log is the bottom of its trunk. */
  fellTree(x: number, y: number, z: number, toward: THREE.Vector3): number {
    if (this.get(x, y, z) !== 'log' || this.get(x, y - 1, z) === 'log') return 0
    const queue: [number, number, number][] = [[x, y, z]], seen = new Set<string>(), blocks: { x: number; y: number; z: number; type: BlockType }[] = []
    while (queue.length) {
      const [bx, by, bz] = queue.pop()!, key = this.key(bx, by, bz)
      if (Math.abs(bx - x) > 2 || Math.abs(bz - z) > 2 || by < y || by > y + 8) continue
      if (seen.has(key)) continue
      seen.add(key)
      const type = this.get(bx, by, bz)
      if (type !== 'log' && type !== 'leaves') continue
      if (type === 'log' && (bx !== x || bz !== z)) continue
      blocks.push({ x: bx, y: by, z: bz, type })
      for (const [dx, dy, dz] of FACE_OFFSETS) queue.push([bx + dx, by + dy, bz + dz])
    }
    const pivotY = Math.min(...blocks.filter(b => b.type === 'log').map(b => b.y))
    const group = new THREE.Group()
    group.position.set(x + 0.5, pivotY, z + 0.5)
    for (const b of blocks) {
      const mesh = new THREE.Mesh(this.fallGeometry, this.fallMaterials[b.type as 'log' | 'leaves'])
      mesh.position.set(b.x - x, b.y - pivotY + 0.5, b.z - z)
      mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh)
    }
    this.meshGroup.add(group)
    const fallDirection = new THREE.Vector3(toward.x, 0, toward.z)
    if (fallDirection.lengthSq() < 1e-6) fallDirection.set(1, 0, 0)
    this.fallingTrees.push({ group, angularVelocity: 0, age: 0, angle: 0, axis: new THREE.Vector3(fallDirection.z, 0, -fallDirection.x).normalize() })
    this.setBatch(blocks.map(b => ({ x: b.x, y: b.y, z: b.z, type: null })))
    return blocks.filter(b => b.type === 'log').length
  }
  private rebuildChunk(ck: string): void {
    const old = this.chunks.get(ck)
    if (old) {
      this.meshGroup.remove(old)
      old.geometry.dispose()
      this.chunks.delete(ck)
      const index = this.collidableMeshes.indexOf(old)
      if (index >= 0) this.collidableMeshes.splice(index, 1)
    }
    const [cx, cz] = ck.split(',').map(Number)
    const ox = cx * CHUNK, oz = cz * CHUNK
    const positions: number[] = [], normals: number[] = [], colors: number[] = [], indices: number[] = []
    for (let x = ox; x < ox + CHUNK; x++) for (let z = oz; z < oz + CHUNK; z++) for (let y = 0; y < 48; y++) {
      const type = this.get(x, y, z)
      if (!type) continue
      const base = COLORS[type]
      const size = type === 'leaves' ? 0.82 : 1
      const inset = (1 - size) * 0.5
      for (let f = 0; f < FACE_DATA.length; f++) {
        const [dx, dy, dz] = FACE_OFFSETS[f]
        const neighbor = this.get(x + dx, y + dy, z + dz)
        if (neighbor && !(type === 'leaves' && neighbor === 'leaves')) continue
        const face = FACE_DATA[f], start = positions.length / 3
        const c = base.clone().multiplyScalar(face.shade * (type === 'leaves' ? leafTint(x, y, z) : 1))
        for (const p of face.corners) {
          positions.push(x - ox + inset + p[0] * size, y + inset + p[1] * size, z - oz + inset + p[2] * size)
          normals.push(...face.n)
          colors.push(c.r, c.g, c.b)
        }
        indices.push(start, start + 1, start + 2, start, start + 2, start + 3)
      }
    }
    if (!positions.length) return
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3))
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
    geometry.setIndex(indices)
    geometry.computeBoundingSphere()
    const mesh = new THREE.Mesh(geometry, this.material)
    mesh.position.set(ox, 0, oz)
    mesh.castShadow = true
    mesh.receiveShadow = true
    mesh.userData.chunk = ck
    this.chunks.set(ck, mesh)
    this.meshGroup.add(mesh)
    this.collidableMeshes.push(mesh)
  }

  /** Highest occupied voxel top at an integer column, or zero outside the bounded island. */
  heightAt(x: number, z: number): number {
    const ix = Math.floor(x), iz = Math.floor(z)
    for (let y = 47; y >= 0; y--) if (this.get(ix, y, iz)) return y + 1
    return 0
  }
  surfaceAt(x: number, z: number): number { return this.heightAt(x, z) }

  /** AABB uses feetY as the lower edge; touching voxel faces without overlap is not a collision. */
  collidesAabb(x: number, feetY: number, z: number, halfWidth: number, height: number): boolean {
    const minX = Math.floor(x - halfWidth + 1e-7), maxX = Math.floor(x + halfWidth - 1e-7)
    const minY = Math.floor(feetY + 1e-7), maxY = Math.floor(feetY + height - 1e-7)
    const minZ = Math.floor(z - halfWidth + 1e-7), maxZ = Math.floor(z + halfWidth - 1e-7)
    for (let bx = minX; bx <= maxX; bx++) for (let by = minY; by <= maxY; by++) for (let bz = minZ; bz <= maxZ; bz++) if (this.get(bx, by, bz)) return true
    return false
  }

  /** Raycast chunk meshes, then step inward from the hit face to recover the exact integer voxel. */
  cast(raycaster: THREE.Raycaster, maxDistance: number): BlockHit | null {
    raycaster.near = 0
    raycaster.far = maxDistance
    const hits = raycaster.intersectObjects(this.collidableMeshes, false)
    for (const hit of hits) {
      if (!hit.face) continue
      const normal = hit.face.normal.clone().transformDirection(hit.object.matrixWorld).round()
      const inside = hit.point.clone().addScaledVector(normal, -1e-4)
      const x = Math.floor(inside.x), y = Math.floor(inside.y), z = Math.floor(inside.z)
      const type = this.get(x, y, z)
      if (type) return { x, y, z, type, point: hit.point.clone(), normal, distance: hit.distance }
    }
    return null
  }

  update(timeSeconds: number, dt = 0): void {
    for (let i = this.fallingTrees.length - 1; i >= 0; i--) {
      const tree = this.fallingTrees[i]; tree.age += dt; tree.angularVelocity += 9.8 * dt
      tree.angle = Math.min(Math.PI / 2, tree.angle + tree.angularVelocity * dt)
      tree.group.quaternion.setFromAxisAngle(new THREE.Vector3(tree.axis.z, 0, -tree.axis.x), tree.angle)
      if (tree.age > 1.8 && tree.angle >= Math.PI / 2) { this.meshGroup.remove(tree.group); this.fallingTrees.splice(i, 1) }
    }
    this.water.material instanceof THREE.MeshStandardMaterial && (this.water.material.opacity = 0.33 + Math.sin(timeSeconds * 0.7) * 0.025)
    const phase = ((timeSeconds % 1) + 1) % 1
    const sunHeight = Math.max(0, Math.sin((phase - 0.25) * Math.PI * 2))
    const light = new THREE.Color('#fff0cf').lerp(new THREE.Color('#637b92'), 1 - sunHeight)
    this.sun.color.copy(light)
    this.sun.intensity = 0.32 + sunHeight * 1.82
    this.skyLight.intensity = 0.9 + sunHeight * 0.82
    this.sun.position.set(Math.cos(phase * Math.PI * 2) * 36, 8 + sunHeight * 46, Math.sin(phase * Math.PI * 2) * 36)
    const sky = new THREE.Color('#a7c3b2').lerp(new THREE.Color('#253b43'), 1 - sunHeight * 0.78)
    if (this.scene.background instanceof THREE.Color) this.scene.background.copy(sky)
    if (this.scene.fog instanceof THREE.Fog) this.scene.fog.color.copy(sky)
    this.water.position.y = 3.15 + Math.sin(timeSeconds * Math.PI * 2) * 0.035
  }

  getVisibleMeshes(): THREE.Mesh[] { return [...this.collidableMeshes, this.water] }

  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    for (const mesh of this.chunks.values()) mesh.geometry.dispose()
    this.chunks.clear()
    this.collidableMeshes.length = 0
    this.meshGroup.clear()
    for (const tree of this.fallingTrees) this.meshGroup.remove(tree.group)
    this.fallingTrees.length = 0
    this.fallGeometry.dispose(); this.fallMaterials.log.dispose(); this.fallMaterials.leaves.dispose()
    this.material.dispose()
    this.water.geometry.dispose()
    if (Array.isArray(this.water.material)) this.water.material.forEach(m => m.dispose()); else this.water.material.dispose()
    this.scene.remove(this.meshGroup, this.water, this.skyLight, this.sun, this.sun.target)
  }
}
