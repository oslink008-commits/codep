BLOCKWILD — SOURCE CODE (UNMINIFIED)

This archive contains the readable TypeScript/JavaScript, CSS, tests, project configuration,
README, and available game assets. It deliberately excludes node_modules, dist, and the
minified standalone HTML build.

Requirements: Node.js 20+ and pnpm 10+

Run locally:
  pnpm install
  pnpm dev

Checks:
  pnpm typecheck
  pnpm test

Create a single-file HTML build (generated/optimized output, not source):
  pnpm html:single

Important: some managed game assets are normally restored by the project runtime. This archive
includes the locally available Moss Warden model and share images where present. Treat current
feature status as described in TODO.md; uncompleted items there are not claimed as implemented.
